ALTER TABLE public.user_settings ADD COLUMN pin_hash text;
ALTER TABLE public.user_settings ADD COLUMN pattern_hash text;
COMMENT ON COLUMN public.user_settings.pin_hash IS 'SHA-256 hex of user_id:PIN, verified server-side only';
COMMENT ON COLUMN public.user_settings.pattern_hash IS 'SHA-256 hex of user_id:pattern, written on first pattern setup';