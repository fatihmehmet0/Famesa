import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-context";

export interface ConversationRow {
  id: string;
  title: string;
  updated_at: string;
}

export function useConversations() {
  const { user } = useApp();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ["conversations", user?.id],
    enabled: !!user,
    queryFn: async (): Promise<ConversationRow[]> => {
      const { data, error } = await supabase
        .from("conversations")
        .select("id, title, updated_at")
        .order("updated_at", { ascending: false });
      if (error) throw error;
      return data as ConversationRow[];
    },
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["conversations", user?.id] });

  const createMutation = useMutation({
    mutationFn: async (title: string) => {
      const { data, error } = await supabase
        .from("conversations")
        .insert({ user_id: user!.id, title })
        .select("id, title, updated_at")
        .single();
      if (error) throw error;
      return data as ConversationRow;
    },
    onSuccess: invalidate,
  });

  const renameMutation = useMutation({
    mutationFn: async ({ id, title }: { id: string; title: string }) => {
      const { error } = await supabase.from("conversations").update({ title }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("conversations").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const deleteAllMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("conversations").delete().eq("user_id", user!.id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  return {
    conversations: query.data ?? [],
    isLoading: query.isLoading,
    createConversation: createMutation.mutateAsync,
    renameConversation: renameMutation.mutateAsync,
    deleteConversation: deleteMutation.mutateAsync,
    deleteAllConversations: deleteAllMutation.mutateAsync,
  };
}
