import { useCallback, useEffect, useRef, useState } from "react";
import * as maplibregl from "maplibre-gl";
import type { Geometry } from "geojson";
import "maplibre-gl/dist/maplibre-gl.css";
import { Crosshair, MapPin, Share2, X } from "lucide-react";
import { toast } from "sonner";

import { useApp } from "@/lib/app-context";

type Position = { lat: number; lng: number; speed: number | null };
type RouteInfo = { distanceKm: number; durationMin: number };

const DARK_STYLE = "https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json";

/** Convert oklch(L C H) to sRGB — maplibre's color parser rejects oklch strings. */
function oklchToSrgb(l: number, c: number, h: number): [number, number, number] {
  const hr = (h * Math.PI) / 180;
  const a = c * Math.cos(hr);
  const b = c * Math.sin(hr);
  const l3 = (l + 0.3963377774 * a + 0.2158037573 * b) ** 3;
  const m3 = (l - 0.1055613458 * a - 0.0638541728 * b) ** 3;
  const s3 = (l - 0.0894841775 * a - 1.291485548 * b) ** 3;
  const toSrgb = (x: number) => (x <= 0.0031308 ? 12.92 * x : 1.055 * x ** (1 / 2.4) - 0.055);
  const clamp = (v: number) => Math.round(Math.min(1, Math.max(0, v)) * 255);
  return [
    clamp(toSrgb(4.0767416621 * l3 - 3.3077115913 * m3 + 0.2309699292 * s3)),
    clamp(toSrgb(-1.2684380046 * l3 + 2.6097574011 * m3 - 0.3413193965 * s3)),
    clamp(toSrgb(-0.0041960863 * l3 - 0.7034186147 * m3 + 1.707614701 * s3)),
  ];
}

/** Resolve a CSS custom property to an rgb()/hex color maplibre accepts. */
function cssColor(name: string, fallback: string): string {
  const raw = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  if (!raw) return fallback;
  if (raw.startsWith("oklch(")) {
    const parts = (raw.slice(6, raw.indexOf(")")).split("/")[0] ?? "").trim().split(/\s+/);
    if (parts.length >= 3) {
      const pl = parts[0] ?? "0";
      const l = parseFloat(pl) / (pl.includes("%") ? 100 : 1);
      const c = parseFloat(parts[1] ?? "0");
      const h = parseFloat(parts[2] ?? "0"); // parseFloat strips a trailing "deg"
      const [r, g, b] = oklchToSrgb(l, c, h);
      return `rgb(${r}, ${g}, ${b})`;
    }
  }
  const ctx = document.createElement("canvas").getContext("2d");
  if (!ctx) return fallback;
  ctx.fillStyle = raw;
  return ctx.fillStyle || fallback;
}

function withAlpha(color: string, alpha: number): string {
  const rgb = color.match(/^rgb\(\s*(\d+),\s*(\d+),\s*(\d+)\s*\)$/);
  if (rgb) return `rgba(${rgb[1]}, ${rgb[2]}, ${rgb[3]}, ${alpha})`;
  if (color.startsWith("#")) {
    const hex = color.slice(1);
    const value = parseInt(hex.length === 3 ? hex.split("").map((c) => c + c).join("") : hex, 16);
    return `rgba(${(value >> 16) & 255}, ${(value >> 8) & 255}, ${value & 255}, ${alpha})`;
  }
  return color;
}

/** Repaint the dark basemap in the active FAMESA theme (gold obsidian aware). */
function applyFamesaTheme(map: maplibregl.Map) {
  const background = cssColor("--background", "#0a0908");
  const primary = cssColor("--primary", "#d4a853");
  const foreground = cssColor("--foreground", "#f5f0e6");
  const muted = cssColor("--muted-foreground", "#a89f8d");
  for (const layer of map.getStyle().layers) {
    const id = layer.id.toLowerCase();
    try {
      if (layer.type === "background") {
        map.setPaintProperty(layer.id, "background-color", background);
      } else if (layer.type === "fill" && (id.includes("water") || id.includes("ocean"))) {
        map.setPaintProperty(layer.id, "fill-color", withAlpha(background, 0.9));
      } else if (layer.type === "line" && (id.includes("road") || id.includes("street") || id.includes("highway") || id.includes("path"))) {
        map.setPaintProperty(layer.id, "line-color", withAlpha(primary, id.includes("highway") || id.includes("motorway") ? 0.75 : 0.45));
      } else if (layer.type === "symbol" && id.includes("label")) {
        map.setPaintProperty(layer.id, "text-color", id.includes("water") ? muted : foreground);
        map.setPaintProperty(layer.id, "text-halo-color", background);
        map.setPaintProperty(layer.id, "text-halo-width", 1.2);
      }
    } catch {
      // layer does not accept this paint property — skip
    }
  }
}

function makeMarkerElement(kind: "me" | "dest"): HTMLDivElement {
  const el = document.createElement("div");
  el.className = kind === "me" ? "map-marker-me" : "map-marker-dest";
  return el;
}

export default function FamesaMap() {
  const { t } = useApp();
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const meMarkerRef = useRef<maplibregl.Marker | null>(null);
  const destMarkerRef = useRef<maplibregl.Marker | null>(null);
  const lastFixRef = useRef<{ lat: number; lng: number; time: number } | null>(null);

  const [position, setPosition] = useState<Position | null>(null);
  const [destination, setDestination] = useState<{ lat: number; lng: number } | null>(null);
  const [route, setRoute] = useState<RouteInfo | null>(null);
  const [locating, setLocating] = useState(true);
  const [follow, setFollow] = useState(true);

  // Live position tracking
  useEffect(() => {
    if (!navigator.geolocation) {
      setLocating(false);
      toast.error(t("map.locateError"));
      return;
    }
    const watch = navigator.geolocation.watchPosition(
      (fix) => {
        const prev = lastFixRef.current;
        let speed = fix.coords.speed;
        if ((speed === null || Number.isNaN(speed)) && prev) {
          const dt = (fix.timestamp - prev.time) / 1000;
          if (dt > 0.5) {
            const R = 6371000;
            const dLat = ((fix.coords.latitude - prev.lat) * Math.PI) / 180;
            const dLng = ((fix.coords.longitude - prev.lng) * Math.PI) / 180;
            const a = Math.sin(dLat / 2) ** 2 + Math.cos((prev.lat * Math.PI) / 180) * Math.cos((fix.coords.latitude * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
            speed = (2 * R * Math.asin(Math.sqrt(a))) / dt;
          }
        }
        lastFixRef.current = { lat: fix.coords.latitude, lng: fix.coords.longitude, time: fix.timestamp };
        setPosition({ lat: fix.coords.latitude, lng: fix.coords.longitude, speed });
        setLocating(false);
      },
      () => {
        setLocating(false);
        toast.error(t("map.locateError"));
      },
      { enableHighAccuracy: true, maximumAge: 2000, timeout: 15000 },
    );
    return () => navigator.geolocation.clearWatch(watch);
  }, [t]);

  // Map lifecycle
  useEffect(() => {
    const container = containerRef.current;
    if (!container || mapRef.current) return;
    const map = new maplibregl.Map({
      container,
      style: DARK_STYLE,
      center: [32.85, 39.92],
      zoom: 5,
      attributionControl: false,
    });
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), "bottom-right");
    map.on("load", () => applyFamesaTheme(map));
    map.on("dragstart", () => setFollow(false));
    map.on("click", (e) => {
      setDestination({ lat: e.lngLat.lat, lng: e.lngLat.lng });
    });
    mapRef.current = map;
    return () => {
      mapRef.current = null;
      map.remove();
    };
  }, []);

  // Position marker + camera follow
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !position) return;
    if (!meMarkerRef.current) {
      meMarkerRef.current = new maplibregl.Marker({ element: makeMarkerElement("me") }).setLngLat([position.lng, position.lat]).addTo(map);
    } else {
      meMarkerRef.current.setLngLat([position.lng, position.lat]);
    }
    if (follow) map.easeTo({ center: [position.lng, position.lat], zoom: Math.max(map.getZoom(), 15), duration: 600 });
  }, [position, follow]);

  // Destination marker + route fetch
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (!destination) {
      destMarkerRef.current?.remove();
      destMarkerRef.current = null;
      setRoute(null);
      if (map.getSource("route")) {
        map.removeLayer("route-line");
        map.removeLayer("route-casing");
        map.removeSource("route");
      }
      return;
    }
    if (!destMarkerRef.current) {
      destMarkerRef.current = new maplibregl.Marker({ element: makeMarkerElement("dest") }).setLngLat([destination.lng, destination.lat]).addTo(map);
    } else {
      destMarkerRef.current.setLngLat([destination.lng, destination.lat]);
    }
    if (!position) return;
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch(
          `https://router.project-osrm.org/route/v1/driving/${position.lng},${position.lat};${destination.lng},${destination.lat}?overview=full&geometries=geojson`,
        );
        const data = (await res.json()) as { routes?: { distance: number; duration: number; geometry: Geometry }[] };
        const best = data.routes?.[0];
        if (!best || cancelled) return;
        setRoute({ distanceKm: best.distance / 1000, durationMin: best.duration / 60 });
        const source = map.getSource("route") as maplibregl.GeoJSONSource | undefined;
        if (source) {
          source.setData({ type: "Feature", properties: {}, geometry: best.geometry });
        } else {
          map.addSource("route", { type: "geojson", data: { type: "Feature", properties: {}, geometry: best.geometry } });
          const primary = cssColor("--primary", "#d4a853");
          map.addLayer({ id: "route-casing", type: "line", source: "route", paint: { "line-color": withAlpha(primary, 0.25), "line-width": 10, "line-blur": 6 } });
          map.addLayer({ id: "route-line", type: "line", source: "route", paint: { "line-color": primary, "line-width": 4 } });
        }
        const bounds = new maplibregl.LngLatBounds([position.lng, position.lat], [destination.lng, destination.lat]);
        map.fitBounds(bounds, { padding: 90, duration: 800 });
      } catch {
        if (!cancelled) toast.error(t("common.error"));
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [destination, position === null, t]); // eslint-disable-line react-hooks/exhaustive-deps

  const share = useCallback(() => {
    if (!position) return;
    const url = `https://www.openstreetmap.org/?mlat=${position.lat.toFixed(6)}&mlon=${position.lng.toFixed(6)}#map=16/${position.lat.toFixed(6)}/${position.lng.toFixed(6)}`;
    void navigator.clipboard.writeText(url).then(() => toast.success(t("map.copied")));
  }, [position, t]);

  const speedKmh = position?.speed != null && position.speed > 0.3 ? position.speed * 3.6 : 0;
  const etaMin = route ? (speedKmh > 3 ? (route.distanceKm / speedKmh) * 60 : route.durationMin) : null;
  const etaText = etaMin === null ? "—" : etaMin >= 60 ? `${Math.floor(etaMin / 60)} sa ${Math.round(etaMin % 60)} dk` : `${Math.round(etaMin)} dk`;

  return (
    <div className="relative h-[calc(100vh-4rem)] lg:h-screen">
      <div className="absolute inset-0">
        <div ref={containerRef} className="h-full w-full" />
      </div>

      <div className="pointer-events-none absolute left-1/2 top-4 z-10 -translate-x-1/2">
        <div className="glass-panel-strong glow-edge px-5 py-2 text-center">
          <span className="font-mono text-[11px] tracking-[0.35em] text-primary">{t("map.title")}</span>
        </div>
      </div>

      {locating && (
        <div className="absolute left-1/2 top-20 z-10 -translate-x-1/2">
          <span className="glass-panel px-4 py-2 font-mono text-[10px] tracking-[0.25em] text-muted-foreground">{t("map.locating")}</span>
        </div>
      )}

      <div className="absolute bottom-6 left-1/2 z-10 w-[min(92vw,28rem)] -translate-x-1/2">
        <div className="glass-panel-strong fade-up p-4">
          {!destination ? (
            <p className="text-center text-xs text-muted-foreground">{t("map.hint")}</p>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 font-mono text-[10px] tracking-[0.25em] text-primary">
                  <MapPin className="h-3.5 w-3.5" /> {t("map.destination")}
                </span>
                <button onClick={() => setDestination(null)} className="flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground">
                  <X className="h-3.5 w-3.5" /> {t("map.clearDest")}
                </button>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="glass-panel px-2 py-3">
                  <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground">{t("map.distance")}</div>
                  <div className="mt-1 font-display text-lg font-bold text-foreground">{route ? route.distanceKm.toFixed(1) : "—"} km</div>
                </div>
                <div className="glass-panel px-2 py-3">
                  <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground">{t("map.speed")}</div>
                  <div className="mt-1 font-display text-lg font-bold text-primary">{speedKmh.toFixed(0)} km/h</div>
                </div>
                <div className="glass-panel px-2 py-3">
                  <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground">{t("map.eta")}</div>
                  <div className="mt-1 font-display text-lg font-bold text-foreground">{etaText}</div>
                </div>
              </div>
            </div>
          )}
          <div className="mt-3 flex gap-2">
            <button
              onClick={() => position && (setFollow(true), mapRef.current?.easeTo({ center: [position.lng, position.lat], zoom: 15, duration: 600 }))}
              className="glass-panel flex flex-1 items-center justify-center gap-2 px-3 py-2.5 text-xs text-foreground transition-transform hover:scale-[1.02]"
            >
              <Crosshair className="h-4 w-4 text-primary" /> {t("map.title")}
            </button>
            <button
              onClick={share}
              disabled={!position}
              className="glass-panel flex flex-1 items-center justify-center gap-2 px-3 py-2.5 text-xs text-foreground transition-transform hover:scale-[1.02] disabled:opacity-40"
            >
              <Share2 className="h-4 w-4 text-primary" /> {t("map.share")}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
