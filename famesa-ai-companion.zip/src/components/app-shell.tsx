import { useEffect, useState, type ReactNode } from "react";
import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import {
  Bell,
  Brain,
  Camera,
  Cpu,
  FolderOpen,
  HelpCircle,
  Map,
  Menu,
  MessageSquarePlus,
  MessagesSquare,
  Mic,
  Pencil,
  Search,
  Settings,
  Share2,
  Trash2,
  X,
} from "lucide-react";

import logoUrl from "@/assets/famesa-logo.png";
import { SecurityGate } from "@/components/security/security-gate";
import { useApp } from "@/lib/app-context";
import { useConversations, type ConversationRow } from "@/hooks/use-conversations";

export function BootScreen() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <span className="font-mono text-[11px] tracking-[0.3em] text-muted-foreground">FAMESA</span>
    </div>
  );
}

export function RequireAuth({ children }: { children: ReactNode }) {
  const { session, loading, profile } = useApp();
  const location = useLocation();
  const navigate = useNavigate();
  const redirectTo =
    !loading && !session
      ? "/auth"
      : !loading && session && profile && !profile.onboarding_completed && location.pathname !== "/onboarding"
        ? "/onboarding"
        : null;

  useEffect(() => {
    if (redirectTo) void navigate({ to: redirectTo });
  }, [redirectTo, navigate]);

  if (loading || (session && profile === null) || redirectTo) return <BootScreen />;
  return <SecurityGate>{children}</SecurityGate>;
}

function ConversationItem({
  conversation,
  onNavigate,
}: {
  conversation: ConversationRow;
  onNavigate?: (() => void) | undefined;
}) {
  const { t } = useApp();
  const { renameConversation, deleteConversation } = useConversations();
  const location = useLocation();
  const navigate = useNavigate();
  const active = location.pathname === `/chat/${conversation.id}`;
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(conversation.title);

  const commitRename = async () => {
    setEditing(false);
    const title = draft.trim();
    if (title && title !== conversation.title) {
      await renameConversation({ id: conversation.id, title });
    }
  };

  return (
    <div
      className={`group flex items-center gap-2 rounded-xl px-3 py-2 text-sm transition-colors ${
        active ? "bg-accent/60 text-foreground glow-edge" : "text-muted-foreground hover:bg-accent/30 hover:text-foreground"
      }`}
    >
      {editing ? (
        <input
          autoFocus
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onBlur={() => void commitRename()}
          onKeyDown={(e) => {
            if (e.key === "Enter") void commitRename();
            if (e.key === "Escape") setEditing(false);
          }}
          className="w-full rounded-md bg-background/60 px-2 py-1 text-sm text-foreground outline-none ring-1 ring-ring/40"
        />
      ) : (
        <>
          <button
            className="flex-1 truncate text-left"
            onClick={() => {
              void navigate({ to: "/chat/$threadId", params: { threadId: conversation.id } });
              onNavigate?.();
            }}
            onDoubleClick={() => {
              setDraft(conversation.title);
              setEditing(true);
            }}
            title={conversation.title}
          >
            {conversation.title}
          </button>
          <button
            aria-label={t("chat.rename")}
            className="opacity-0 transition-opacity group-hover:opacity-100"
            onClick={() => {
              setDraft(conversation.title);
              setEditing(true);
            }}
          >
            <Pencil className="h-3.5 w-3.5" />
          </button>
          <button
            aria-label={t("chat.delete")}
            className="opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
            onClick={() => void deleteConversation(conversation.id)}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </>
      )}
    </div>
  );
}

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const { t, profile, signOut, settings } = useApp();
  const { conversations, createConversation } = useConversations();
  const navigate = useNavigate();
  const [search, setSearch] = useState("");

  const filtered = conversations.filter((c) => c.title.toLocaleLowerCase().includes(search.toLocaleLowerCase()));

  const navItems = [
    { to: "/", icon: MessagesSquare, label: t("nav.chats") },
    { to: "/map", icon: Map, label: t("nav.map") },
    { to: "/memories", icon: Brain, label: t("nav.memories") },
    { to: "/files", icon: FolderOpen, label: t("nav.files") },
    { to: "/voice", icon: Mic, label: t("nav.voice") },
    { to: "/camera", icon: Camera, label: t("nav.camera") },
    { to: "/models", icon: Cpu, label: t("nav.models") },
    { to: "/notifications", icon: Bell, label: t("nav.notifications") },
    { to: "/social", icon: Share2, label: t("nav.social") },
    { to: "/settings", icon: Settings, label: t("nav.settings") },
    { to: "/help", icon: HelpCircle, label: t("nav.help") },
  ] as const;

  return (
    <div className="flex h-full flex-col gap-4 p-4">
      <Link to="/" className="flex items-center gap-3 px-2 pt-1" onClick={onNavigate}>
        <img src={logoUrl} alt="FAMESA AI" className="h-9 w-9 drop-shadow-[0_0_12px_var(--color-glow)]" />
        <div>
          <div className="font-display text-lg font-bold tracking-tight text-foreground">
            FAMESA <span className="text-primary">AI</span>
          </div>
          <div className="font-mono text-[10px] tracking-[0.25em] text-muted-foreground">PERSONAL CORE</div>
        </div>
      </Link>

      <button
        onClick={async () => {
          const conversation = await createConversation(t("chat.untitled"));
          void navigate({ to: "/chat/$threadId", params: { threadId: conversation.id } });
          onNavigate?.();
        }}
        className="glass-panel glow-edge flex items-center justify-center gap-2 px-4 py-3 text-sm font-medium text-foreground transition-transform hover:scale-[1.02] active:scale-[0.98]"
      >
        <MessageSquarePlus className="h-4 w-4 text-primary" />
        {t("nav.newChat")}
      </button>

      <div className="glass-panel flex items-center gap-2 px-3 py-2">
        <Search className="h-4 w-4 text-muted-foreground" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={t("chat.search")}
          className="w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
        />
      </div>

      <div className="flex-1 space-y-0.5 overflow-y-auto">
        {filtered.map((conversation) => (
          <ConversationItem key={conversation.id} conversation={conversation} onNavigate={onNavigate} />
        ))}
        {filtered.length === 0 && (
          <p className="px-3 py-4 text-center text-xs text-muted-foreground">{t("chat.empty")}</p>
        )}
      </div>

      <nav className="grid grid-cols-2 gap-1 border-t border-border pt-3">
        {navItems.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            onClick={onNavigate}
            className="flex items-center gap-2 rounded-lg px-2.5 py-2 text-xs text-muted-foreground transition-colors hover:bg-accent/40 hover:text-foreground"
            activeProps={{ className: "bg-accent/60 text-foreground" }}
          >
            <item.icon className="h-4 w-4 text-primary/80" />
            {item.label}
          </Link>
        ))}
      </nav>

      <div className="flex items-center gap-3 border-t border-border pt-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-accent font-display text-sm font-bold text-primary">
          {(profile?.display_name ?? profile?.username ?? "F").charAt(0).toLocaleUpperCase()}
        </div>
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-medium text-foreground">
            {profile?.display_name ?? profile?.username ?? "FAMESA"}
          </div>
          <button onClick={() => void signOut()} className="text-xs text-muted-foreground hover:text-foreground">
            {t("nav.logout")}
          </button>
        </div>
        <span className="font-mono text-[9px] tracking-widest text-primary/60">{settings.ai_name}</span>
      </div>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const { t } = useApp();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="ambient-field" />

      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-72 border-r border-border bg-sidebar/80 backdrop-blur-xl lg:block">
        <SidebarContent />
      </aside>

      {/* Mobile top bar */}
      <header className="fixed inset-x-0 top-0 z-30 flex items-center gap-3 border-b border-border bg-background/70 px-4 py-3 backdrop-blur-xl lg:hidden">
        <button aria-label="Menu" onClick={() => setDrawerOpen(true)} className="glass-panel p-2">
          <Menu className="h-5 w-5 text-foreground" />
        </button>
        <Link to="/" className="flex items-center gap-2">
          <img src={logoUrl} alt="" className="h-7 w-7" />
          <span className="font-display text-base font-bold text-foreground">
            FAMESA <span className="text-primary">AI</span>
          </span>
        </Link>
        <div className="flex-1" />
        <button aria-label={t("nav.notifications")} onClick={() => void navigate({ to: "/notifications" })} className="glass-panel p-2">
          <Bell className="h-5 w-5 text-foreground" />
        </button>
      </header>

      {/* Mobile drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-background/70 backdrop-blur-sm fade-in" onClick={() => setDrawerOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-[85vw] max-w-80 border-r border-border bg-sidebar scale-in">
            <button
              aria-label={t("common.close")}
              onClick={() => setDrawerOpen(false)}
              className="absolute right-3 top-3 z-10 glass-panel p-2"
            >
              <X className="h-4 w-4 text-foreground" />
            </button>
            <SidebarContent onNavigate={() => setDrawerOpen(false)} />
          </div>
        </div>
      )}

      <main className="relative z-10 pt-16 lg:pl-72 lg:pt-0">{children}</main>
    </div>
  );
}
