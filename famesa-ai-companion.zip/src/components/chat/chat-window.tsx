import { useEffect, useMemo, useRef, useState } from "react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type FileUIPart, type UIMessage } from "ai";
import {
  Camera,
  FileUp,
  Image as ImageIcon,
  Loader2,
  Mic,
  Paperclip,
  Send,
  Square,
  ThumbsDown,
  ThumbsUp,
  Volume2,
  X,
} from "lucide-react";
import { Streamdown } from "streamdown";
import { toast } from "sonner";

import logoUrl from "@/assets/famesa-logo.png";
import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-context";
import { useConversations } from "@/hooks/use-conversations";
import { dataUrlToFile, extractVideoFrames, fileToDataUrl } from "@/lib/media";

const DEFAULT_TITLES = ["Yeni sohbet", "New chat"];

function ProcessingIndicator({ label }: { label: string }) {
  return (
    <div className="fade-in flex items-center gap-3 px-1 py-2">
      <div className="processing-core" />
      <div className="glass-panel data-stream flex-1 px-4 py-2.5">
        <span className="font-mono text-[11px] tracking-[0.3em] text-primary">{label}</span>
      </div>
    </div>
  );
}

function MessageBubble({
  message,
  conversationId,
  onSpeak,
}: {
  message: UIMessage;
  conversationId: string;
  onSpeak: (text: string) => void;
}) {
  const { t, user } = useApp();
  const [rated, setRated] = useState<0 | 1 | -1>(0);
  const isUser = message.role === "user";

  const rate = async (rating: 1 | -1) => {
    if (rated) return;
    setRated(rating);
    const { data: row } = await supabase
      .from("messages")
      .select("id")
      .eq("sdk_id", message.id)
      .maybeSingle();
    await supabase.from("feedback").insert({
      user_id: user!.id,
      conversation_id: conversationId,
      message_id: row?.id ?? null,
      rating,
    });
    toast.success(t("set.saved"));
  };

  const textContent = message.parts
    .filter((p) => p.type === "text")
    .map((p) => (p as { text: string }).text)
    .join("");

  return (
    <div className={`fade-up flex gap-3 ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && (
        <img
          src={logoUrl}
          alt=""
          className="mt-1 h-7 w-7 shrink-0 drop-shadow-[0_0_10px_var(--color-glow)]"
          width={1024}
          height={1024}
          loading="lazy"
        />
      )}
      <div className={`max-w-[85%] sm:max-w-[75%] ${isUser ? "order-first" : ""}`}>
        <div
          className={
            isUser
              ? "glass-panel px-4 py-3 text-sm text-foreground"
              : "px-1 py-1 text-[15px] leading-relaxed text-foreground"
          }
        >
          {message.parts.map((part, i) => {
            if (part.type === "text") {
              return isUser ? (
                <span key={i} className="whitespace-pre-wrap">{(part as { text: string }).text}</span>
              ) : (
                <Streamdown key={i}>{(part as { text: string }).text}</Streamdown>
              );
            }
            if (part.type === "reasoning") {
              return (
                <details key={i} className="mb-2 rounded-xl border border-border/60 bg-background/40 px-3 py-2">
                  <summary className="cursor-pointer font-mono text-[10px] tracking-[0.25em] text-muted-foreground">
                    {t("chat.reasoning")}
                  </summary>
                  <p className="mt-2 whitespace-pre-wrap text-xs text-muted-foreground">
                    {(part as { text: string }).text}
                  </p>
                </details>
              );
            }
            if (part.type === "file") {
              const file = part as { url: string; mediaType?: string; filename?: string };
              if (file.mediaType?.startsWith("image/")) {
                return (
                  <img
                    key={i}
                    src={file.url}
                    alt={file.filename ?? ""}
                    className="my-2 max-h-80 rounded-xl border border-border"
                    loading="lazy"
                  />
                );
              }
              return (
                <div key={i} className="my-2 flex items-center gap-2 rounded-xl border border-border px-3 py-2 text-xs">
                  <Paperclip className="h-3.5 w-3.5 text-primary" />
                  {file.filename ?? "dosya"}
                </div>
              );
            }
            if (part.type === "tool-save_memory") {
              const toolPart = part as { state: string; output?: { saved?: boolean; content?: string } };
              return (
                <div key={i} className="my-2 flex items-center gap-2 rounded-xl border border-primary/30 bg-primary/10 px-3 py-2 text-xs text-primary">
                  <span className="processing-core" style={{ width: 8, height: 8 }} />
                  {toolPart.state === "output-available" && toolPart.output?.saved
                    ? `${t("chat.memorySaved")}: ${toolPart.output.content ?? ""}`
                    : t("common.loading")}
                </div>
              );
            }
            return null;
          })}
        </div>
        {!isUser && message.role === "assistant" && (
          <div className="mt-1 flex items-center gap-1 px-1 opacity-60">
            <button
              aria-label="good"
              onClick={() => void rate(1)}
              className={`rounded-lg p-1.5 hover:bg-accent/50 ${rated === 1 ? "text-primary" : ""}`}
            >
              <ThumbsUp className="h-3.5 w-3.5" />
            </button>
            <button
              aria-label="bad"
              onClick={() => void rate(-1)}
              className={`rounded-lg p-1.5 hover:bg-accent/50 ${rated === -1 ? "text-destructive" : ""}`}
            >
              <ThumbsDown className="h-3.5 w-3.5" />
            </button>
            {textContent && (
              <button aria-label={t("chat.listen")} onClick={() => onSpeak(textContent)} className="rounded-lg p-1.5 hover:bg-accent/50">
                <Volume2 className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export function ChatWindow({ threadId, initialMessages }: { threadId: string; initialMessages: UIMessage[] }) {
  const { t, session, settings } = useApp();
  const { renameConversation, conversations } = useConversations();
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState<File[]>([]);
  const [analyzing, setAnalyzing] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        body: { conversationId: threadId },
        ...(session ? { headers: { Authorization: `Bearer ${session.access_token}` } } : {}),
      }),
    [threadId, session],
  );

  const { messages, sendMessage, status, stop, error } = useChat({
    id: threadId,
    messages: initialMessages,
    transport,
    onError: () => toast.error(t("chat.error")),
  });

  const busy = status === "submitted" || status === "streaming";

  // Pick up a pending camera capture
  useEffect(() => {
    const pending = sessionStorage.getItem("famesa:pending-image");
    if (pending) {
      sessionStorage.removeItem("famesa:pending-image");
      setAttachments([dataUrlToFile(pending, "kamera.jpg")]);
    }
    const pendingMessage = sessionStorage.getItem("famesa:pending-message");
    if (pendingMessage) {
      sessionStorage.removeItem("famesa:pending-message");
      void sendMessage({ text: pendingMessage });
    }
    inputRef.current?.focus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [threadId]);

  // Auto-scroll
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [messages, status]);

  // Auto-speak
  useEffect(() => {
    if (!settings.auto_speak || status !== "ready") return;
    const last = messages[messages.length - 1];
    if (last?.role !== "assistant") return;
    const text = last.parts
      .filter((p) => p.type === "text")
      .map((p) => (p as { text: string }).text)
      .join("");
    if (text) void speak(text);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  const speak = async (text: string) => {
    try {
      audioRef.current?.pause();
      const response = await fetch("/api/tts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(session ? { Authorization: `Bearer ${session.access_token}` } : {}),
        },
        body: JSON.stringify({ text: text.slice(0, 1500), voice: settings.tts_voice }),
      });
      if (!response.ok) throw new Error("tts");
      const blob = await response.blob();
      const audio = new Audio(URL.createObjectURL(blob));
      audio.playbackRate = settings.voice_speed;
      audioRef.current = audio;
      await audio.play();
    } catch {
      toast.error(t("common.error"));
    }
  };

  const maybeAutoTitle = async (text: string) => {
    const conversation = conversations.find((c) => c.id === threadId);
    if (conversation && DEFAULT_TITLES.includes(conversation.title) && messages.length === 0) {
      const title = text.trim().slice(0, 42) || conversation.title;
      await renameConversation({ id: threadId, title });
    }
  };

  const handleFiles = async (fileList: FileList | null) => {
    if (!fileList?.length) return;
    const file = fileList[0];
    if (!file) return;
    if (file.type.startsWith("video/")) {
      setAnalyzing(true);
      try {
        const frames = await extractVideoFrames(file);
        setAttachments((prev) => [...prev, ...frames]);
        toast.success(t("chat.videoFrames"));
      } catch {
        toast.error(t("files.uploadError"));
      } finally {
        setAnalyzing(false);
      }
      return;
    }
    setAttachments((prev) => [...prev, ...Array.from(fileList).slice(0, 4)]);
  };

  const submit = async () => {
    const text = input.trim();
    if ((!text && attachments.length === 0) || busy) return;
    setInput("");
    const files = attachments;
    setAttachments([]);
    if (text) void maybeAutoTitle(text);
    const parts: FileUIPart[] = [];
    for (const file of files) {
      parts.push({
        type: "file",
        mediaType: file.type || "image/jpeg",
        url: await fileToDataUrl(file),
        filename: file.name,
      });
    }
    await sendMessage({ text: text || t("camera.show"), ...(parts.length ? { files: parts } : {}) });
    inputRef.current?.focus();
  };

  return (
    <div className="flex h-[calc(100vh-4rem)] flex-col lg:h-screen">
      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-6 sm:px-8">
        <div className="mx-auto max-w-3xl space-y-5">
          {messages.length === 0 && !busy && (
            <div className="flex flex-col items-center gap-4 py-20 text-center">
              <img src={logoUrl} alt="" className="h-16 w-16 drop-shadow-[0_0_24px_var(--color-glow)]" width={1024} height={1024} />
              <p className="text-sm text-muted-foreground">{t("home.subtitle")}</p>
            </div>
          )}
          {messages.map((message) => (
            <MessageBubble key={message.id} message={message} conversationId={threadId} onSpeak={(text) => void speak(text)} />
          ))}
          {status === "submitted" && (
            <ProcessingIndicator label={attachments.length ? t("chat.analyzing") : t("chat.processing")} />
          )}
          {analyzing && <ProcessingIndicator label={t("chat.analyzing")} />}
          {error && (
            <div className="glass-panel border-destructive/40 px-4 py-3 text-sm text-destructive">{t("chat.error")}</div>
          )}
        </div>
      </div>

      {/* Composer */}
      <div className="border-t border-border bg-background/60 px-4 py-3 backdrop-blur-xl sm:px-8">
        <div className="mx-auto max-w-3xl">
          {attachments.length > 0 && (
            <div className="mb-2 flex flex-wrap gap-2">
              {attachments.map((file, i) => (
                <div key={i} className="glass-panel flex items-center gap-2 px-3 py-1.5 text-xs text-foreground">
                  <ImageIcon className="h-3.5 w-3.5 text-primary" />
                  <span className="max-w-32 truncate">{file.name}</span>
                  <button aria-label={t("common.close")} onClick={() => setAttachments((prev) => prev.filter((_, j) => j !== i))}>
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
          <div className="glass-panel-strong glow-edge flex items-end gap-2 p-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,video/*,audio/*,.pdf,.txt,.md"
              className="hidden"
              onChange={(e) => {
                void handleFiles(e.target.files);
                e.target.value = "";
              }}
            />
            <button
              aria-label={t("chat.attach")}
              onClick={() => fileInputRef.current?.click()}
              className="rounded-xl p-2.5 text-muted-foreground transition-colors hover:bg-accent/50 hover:text-foreground"
            >
              <FileUp className="h-5 w-5" />
            </button>
            <button
              aria-label={t("nav.camera")}
              onClick={() => (window.location.href = "/camera")}
              className="rounded-xl p-2.5 text-muted-foreground transition-colors hover:bg-accent/50 hover:text-foreground"
            >
              <Camera className="h-5 w-5" />
            </button>
            <button
              aria-label={t("nav.voice")}
              onClick={() => (window.location.href = "/voice")}
              className="rounded-xl p-2.5 text-muted-foreground transition-colors hover:bg-accent/50 hover:text-foreground"
            >
              <Mic className="h-5 w-5" />
            </button>
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void submit();
                }
              }}
              placeholder={t("home.placeholder")}
              rows={1}
              className="max-h-40 flex-1 resize-none bg-transparent px-2 py-2.5 text-[15px] text-foreground outline-none placeholder:text-muted-foreground"
            />
            {busy ? (
              <button
                aria-label={t("chat.stop")}
                onClick={() => void stop()}
                className="rounded-xl bg-secondary p-2.5 text-secondary-foreground transition-transform hover:scale-105"
              >
                <Square className="h-5 w-5" />
              </button>
            ) : (
              <button
                aria-label={t("chat.send")}
                disabled={!input.trim() && attachments.length === 0}
                onClick={() => void submit()}
                className="rounded-xl bg-primary p-2.5 text-primary-foreground transition-transform hover:scale-105 active:scale-95 disabled:opacity-40"
              >
                <Send className="h-5 w-5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
