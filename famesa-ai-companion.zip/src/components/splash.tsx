import { useEffect, useState } from "react";

const LINES = [
  { text: "$ famesa --init", delay: 120 },
  { text: "> core ............ OK", delay: 620 },
  { text: "> neural link ..... OK", delay: 1000 },
  { text: "> memory .......... OK", delay: 1340 },
];

export function Splash({ onDone }: { onDone: () => void }) {
  const [visibleLines, setVisibleLines] = useState(0);
  const [showBrand, setShowBrand] = useState(false);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];
    LINES.forEach((line, i) => {
      timers.push(setTimeout(() => setVisibleLines(i + 1), line.delay));
    });
    timers.push(setTimeout(() => setShowBrand(true), 1650));
    timers.push(setTimeout(() => setLeaving(true), 2450));
    timers.push(setTimeout(onDone, 2950));
    return () => timers.forEach(clearTimeout);
  }, [onDone]);

  return (
    <div
      className={`fixed inset-0 z-[100] flex items-center justify-center bg-background transition-all duration-500 ${
        leaving ? "opacity-0 blur-sm scale-[1.02]" : "opacity-100"
      }`}
    >
      <div className="ambient-field" />
      <div className="glass-panel relative w-[min(92vw,30rem)] p-6 sm:p-8">
        <div className="mb-5 flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-destructive/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-muted-foreground/50" />
          <span className="h-2.5 w-2.5 rounded-full bg-primary/80" />
          <span className="ml-3 font-mono text-[11px] tracking-widest text-muted-foreground">FAMESA TERMINAL</span>
        </div>
        <div className="min-h-28 font-mono text-sm text-muted-foreground">
          {LINES.slice(0, visibleLines).map((line) => (
            <div key={line.text} className="fade-in leading-7">
              {line.text}
            </div>
          ))}
          {visibleLines === LINES.length && !showBrand && <span className="terminal-caret" />}
        </div>
        <div
          className={`mt-2 transition-all duration-700 ${
            showBrand ? "opacity-100 translate-y-0" : "opacity-0 translate-y-3"
          }`}
        >
          <div className="font-display text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
            Code <span className="text-primary text-glow">famesa</span>
          </div>
          <div className="data-stream mt-4 h-px w-full" />
        </div>
      </div>
    </div>
  );
}
