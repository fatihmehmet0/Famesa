import { useRef, useState } from "react";
import { Fingerprint } from "lucide-react";

import { setupPattern, verifyPattern } from "@/lib/security.functions";
import { useApp } from "@/lib/app-context";

const GRID = 3;
const DOTS = Array.from({ length: 9 }, (_, i) => i);
const SIZE = 264;

type GateError = "gate.patternShort" | "gate.patternMismatch" | "gate.patternWrong";

function dotCenter(index: number) {
  const col = index % GRID;
  const row = Math.floor(index / GRID);
  const cell = SIZE / GRID;
  return { x: col * cell + cell / 2, y: row * cell + cell / 2 };
}

export function PatternLock({ mode, onUnlocked }: { mode: "setup" | "verify"; onUnlocked: () => void }) {
  const { t } = useApp();
  // Dots accumulate in a ref so fast pointer movements never lose events to
  // React's render timing; state mirrors it purely for rendering.
  const selectedRef = useRef<number[]>([]);
  const [selected, setSelected] = useState<number[]>([]);
  const [current, setCurrent] = useState<{ x: number; y: number } | null>(null);
  const [first, setFirst] = useState<number[] | null>(null);
  const [error, setError] = useState<GateError | null>(null);
  const [busy, setBusy] = useState(false);
  const drawing = useRef(false);
  const boardRef = useRef<HTMLDivElement>(null);

  const reset = () => {
    selectedRef.current = [];
    setSelected([]);
    setCurrent(null);
  };

  const flashError = (key: GateError) => {
    setError(key);
    setTimeout(() => {
      setError(null);
      reset();
    }, 900);
  };

  const toBoard = (clientX: number, clientY: number) => {
    const board = boardRef.current;
    if (!board) return null;
    const rect = board.getBoundingClientRect();
    return {
      x: ((clientX - rect.left) / rect.width) * SIZE,
      y: ((clientY - rect.top) / rect.height) * SIZE,
    };
  };

  const hitDot = (clientX: number, clientY: number): number | null => {
    const point = toBoard(clientX, clientY);
    if (!point) return null;
    for (const dot of DOTS) {
      const c = dotCenter(dot);
      if (Math.hypot(point.x - c.x, point.y - c.y) < SIZE / 9) return dot;
    }
    return null;
  };

  const addDot = (dot: number) => {
    if (selectedRef.current.includes(dot)) return;
    selectedRef.current = [...selectedRef.current, dot];
    setSelected(selectedRef.current);
  };

  const finish = async (pattern: number[]) => {
    if (busy) return;
    if (pattern.length < 4) return flashError("gate.patternShort");
    setBusy(true);
    try {
      if (mode === "setup") {
        if (!first) {
          setFirst(pattern);
          reset();
          return;
        }
        if (first.join("-") !== pattern.join("-")) {
          setFirst(null);
          return flashError("gate.patternMismatch");
        }
        const { ok } = await setupPattern({ data: { pattern } });
        if (!ok) return flashError("gate.patternWrong");
        sessionStorage.setItem("famesa_pattern_ok", "1");
        onUnlocked();
      } else {
        const { ok } = await verifyPattern({ data: { pattern } });
        if (!ok) return flashError("gate.patternWrong");
        sessionStorage.setItem("famesa_pattern_ok", "1");
        onUnlocked();
      }
    } finally {
      setBusy(false);
    }
  };

  const onPointerDown = (e: React.PointerEvent) => {
    if (busy) return;
    drawing.current = true;
    reset();
    const dot = hitDot(e.clientX, e.clientY);
    if (dot !== null) addDot(dot);
    const point = toBoard(e.clientX, e.clientY);
    if (point) setCurrent(point);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!drawing.current || busy) return;
    const point = toBoard(e.clientX, e.clientY);
    if (point) setCurrent(point);
    const dot = hitDot(e.clientX, e.clientY);
    if (dot !== null) addDot(dot);
  };

  const onPointerUp = () => {
    if (!drawing.current) return;
    drawing.current = false;
    const pattern = selectedRef.current;
    setCurrent(null);
    void finish(pattern);
  };

  const points = selected.map((dot) => dotCenter(dot));
  const path = points.map((p, i) => `${i === 0 ? "M" : "L"}${p.x},${p.y}`).join(" ");
  const last = points[points.length - 1];

  return (
    <div className="gate-screen">
      <div className="gate-scanlines" />
      <div className={`gate-panel ${error ? "gate-shake" : ""}`}>
        <div className="gate-status-line">
          <Fingerprint className="h-3.5 w-3.5" />
          <span>SECURITY LAYER 3/3</span>
        </div>
        <h1 className="gate-title">{t("gate.patternTitle")}</h1>
        <p className="gate-subtitle">
          {mode === "setup" ? (first ? t("gate.patternConfirm") : t("gate.patternSetup")) : t("gate.patternDraw")}
        </p>

        <div
          ref={boardRef}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerLeave={() => drawing.current && onPointerUp()}
          className="pattern-board"
          style={{ width: SIZE, height: SIZE, touchAction: "none" }}
        >
          <svg className="pointer-events-none absolute inset-0" width={SIZE} height={SIZE}>
            {points.length > 1 && <path d={path} className={`pattern-line ${error ? "pattern-line-error" : ""}`} />}
            {current && last && (
              <line x1={last.x} y1={last.y} x2={current.x} y2={current.y} className={`pattern-line pattern-line-live ${error ? "pattern-line-error" : ""}`} />
            )}
          </svg>
          {DOTS.map((dot) => {
            const c = dotCenter(dot);
            const active = selected.includes(dot);
            return (
              <div
                key={dot}
                className={`pattern-dot ${active ? "pattern-dot-active" : ""} ${error && active ? "pattern-dot-error" : ""}`}
                style={{ left: c.x, top: c.y }}
              />
            );
          })}
        </div>

        {error && <p className="gate-error">{t(error)}</p>}
        <p className="mt-6 font-mono text-[9px] tracking-[0.3em] text-muted-foreground/60">
          {selected.length > 0 ? `● `.repeat(selected.length).trim() : "— — — —"}
        </p>
      </div>
    </div>
  );
}
