import { useState } from "react";
import { Delete, Lock } from "lucide-react";

import { verifyPin } from "@/lib/security.functions";
import { useApp } from "@/lib/app-context";

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "del"];

export function PinLock({ onUnlocked }: { onUnlocked: () => void }) {
  const { t } = useApp();
  const [pin, setPin] = useState("");
  const [error, setError] = useState(false);
  const [busy, setBusy] = useState(false);

  const submit = async (value: string) => {
    setBusy(true);
    const { ok } = await verifyPin({ data: { pin: value } });
    setBusy(false);
    if (ok) {
      sessionStorage.setItem("famesa_pin_ok", "1");
      onUnlocked();
    } else {
      setError(true);
      setPin("");
      setTimeout(() => setError(false), 900);
    }
  };

  const press = (key: string) => {
    if (busy) return;
    if (key === "del") return setPin((p) => p.slice(0, -1));
    if (!/^\d$/.test(key)) return;
    const next = (pin + key).slice(0, 4);
    setPin(next);
    if (next.length === 4) void submit(next);
  };

  return (
    <div className="gate-screen">
      <div className="gate-scanlines" />
      <div className={`gate-panel ${error ? "gate-shake" : ""}`}>
        <div className="gate-status-line">
          <Lock className="h-3.5 w-3.5" />
          <span>SECURITY LAYER 2/3</span>
        </div>
        <h1 className="gate-title">{t("gate.pinTitle")}</h1>
        <p className="gate-subtitle">{t("gate.pinHint")}</p>

        <div className="mt-8 flex justify-center gap-3">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className={`pin-cell ${pin.length > i ? "pin-cell-filled" : ""} ${error ? "pin-cell-error" : ""}`}>
              {pin.length > i ? "●" : ""}
            </div>
          ))}
        </div>

        {error && <p className="gate-error">{t("gate.wrong")}</p>}

        <div className="mx-auto mt-8 grid max-w-56 grid-cols-3 gap-2.5">
          {KEYS.map((key, i) =>
            key === "" ? (
              <div key={i} />
            ) : (
              <button key={i} onClick={() => press(key)} disabled={busy} className="pin-key">
                {key === "del" ? <Delete className="mx-auto h-4 w-4" /> : key}
              </button>
            ),
          )}
        </div>
      </div>
    </div>
  );
}
