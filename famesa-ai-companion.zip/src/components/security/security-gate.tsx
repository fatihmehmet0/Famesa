import { useEffect, useState, type ReactNode } from "react";

import { PinLock } from "@/components/security/pin-lock";
import { PatternLock } from "@/components/security/pattern-lock";
import { getSecurityStatus } from "@/lib/security.functions";
import { useApp } from "@/lib/app-context";

type Stage = "loading" | "pin" | "pattern" | "open";

/**
 * Privacy gate shown after password sign-in: PIN first, then the pattern
 * protocol. Until both pass, no app screen renders at all.
 */
export function SecurityGate({ children }: { children: ReactNode }) {
  const { session, loading } = useApp();
  const [stage, setStage] = useState<Stage>("loading");
  const [patternMode, setPatternMode] = useState<"setup" | "verify">("verify");

  useEffect(() => {
    if (loading || !session) return;
    let cancelled = false;
    void (async () => {
      const status = await getSecurityStatus();
      if (cancelled) return;
      setPatternMode(status.patternSet ? "verify" : "setup");
      const pinOk = sessionStorage.getItem("famesa_pin_ok") === "1";
      const patternOk = sessionStorage.getItem("famesa_pattern_ok") === "1";
      if (!pinOk) return setStage("pin");
      if (!status.patternSet || !patternOk) return setStage("pattern");
      setStage("open");
    })();
    return () => {
      cancelled = true;
    };
  }, [loading, session]);

  if (stage === "loading") {
    return (
      <div className="gate-screen">
        <div className="gate-scanlines" />
        <div className="font-mono text-[10px] tracking-[0.4em] text-primary">AUTHENTICATING…</div>
      </div>
    );
  }
  if (stage === "pin") return <PinLock onUnlocked={() => setStage("pattern")} />; // patternMode already resolved above
  if (stage === "pattern") {
    return <PatternLock mode={patternMode} onUnlocked={() => setStage("open")} />;
  }
  return <>{children}</>;
}
