import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";

const GATEWAY_URL = "https://ai.gateway.lovable.dev";
const STT_MODEL = "openai/gpt-transcribe";
const MAX_AUDIO_BYTES = 20 * 1024 * 1024;

async function verifyUser(request: Request): Promise<boolean> {
  const auth = request.headers.get("authorization");
  if (!auth?.startsWith("Bearer ")) return false;
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) return false;
  const supabase = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      headers: { Authorization: auth },
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
  const { data, error } = await supabase.auth.getUser();
  return !error && !!data.user;
}

/** Accumulate the gateway's streaming transcription SSE into final text. */
async function readTranscription(response: Response): Promise<string> {
  if (!response.ok) {
    throw new Error(`transcription_failed_${response.status}`);
  }
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("text/event-stream")) {
    const json = (await response.json()) as { text?: string };
    return json.text ?? "";
  }
  const reader = response.body!.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let text = "";
  let doneText = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const events = buffer.split("\n\n");
    buffer = events.pop() ?? "";
    for (const event of events) {
      const dataLine = event.split("\n").find((line) => line.startsWith("data:"));
      if (!dataLine) continue;
      const payload = dataLine.slice(5).trim();
      if (!payload || payload === "[DONE]") continue;
      try {
        const parsed = JSON.parse(payload) as { type?: string; delta?: string; text?: string };
        if (parsed.type === "transcript.text.delta" && parsed.delta) text += parsed.delta;
        if (parsed.type === "transcript.text.done" && parsed.text) doneText = parsed.text;
      } catch {
        // ignore malformed SSE chunk
      }
    }
  }
  return doneText || text;
}

export const Route = createFileRoute("/api/stt")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          if (!(await verifyUser(request))) {
            return Response.json({ error: "unauthorized" }, { status: 401 });
          }
          const apiKey = process.env["LOVABLE_API_KEY"];
          if (!apiKey) return Response.json({ error: "ai_not_configured" }, { status: 500 });

          const form = await request.formData();
          const file = form.get("file");
          if (!(file instanceof File) || !file.size || file.size > MAX_AUDIO_BYTES) {
            return Response.json({ error: "invalid_audio" }, { status: 400 });
          }

          const upstream = new FormData();
          upstream.append("model", STT_MODEL);
          const audioFile =
            file.type.startsWith("audio/") || file.type.startsWith("video/")
              ? file
              : new File([file], file.name || "audio.webm", { type: "audio/webm" });
          upstream.append("file", audioFile, audioFile.name || "audio.webm");
          upstream.append("response_format", "json");
          upstream.append("stream", "true");

          const gatewayResponse = await fetch(`${GATEWAY_URL}/v1/audio/transcriptions`, {
            method: "POST",
            headers: { Authorization: `Bearer ${apiKey}` },
            body: upstream,
            signal: request.signal,
          });

          const text = await readTranscription(gatewayResponse);
          if (!text.trim()) return Response.json({ error: "empty_transcript" }, { status: 422 });
          return Response.json({ text });
        } catch (error) {
          if (error instanceof DOMException && error.name === "AbortError") {
            return new Response(null, { status: 499 });
          }
          console.error("stt failed", error);
          return Response.json({ error: "stt_failed" }, { status: 500 });
        }
      },
    },
  },
});
