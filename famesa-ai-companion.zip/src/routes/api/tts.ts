import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";

const GATEWAY_URL = "https://ai.gateway.lovable.dev";
const TTS_MODEL = "google/gemini-3.1-flash-tts-preview";
const MAX_CHARS = 4000;

async function verifyUser(request: Request): Promise<boolean> {
  const auth = request.headers.get("authorization");
  if (!auth?.startsWith("Bearer ")) return false;
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) return false;
  const supabase = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      headers: { Authorization: auth },
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
  const { data, error } = await supabase.auth.getUser();
  return !error && !!data.user;
}

export const Route = createFileRoute("/api/tts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          if (!(await verifyUser(request))) {
            return Response.json({ error: "unauthorized" }, { status: 401 });
          }
          const apiKey = process.env["LOVABLE_API_KEY"];
          if (!apiKey) return Response.json({ error: "ai_not_configured" }, { status: 500 });

          const body = (await request.json()) as { text?: string; voice?: string };
          const text = (body.text ?? "").trim().slice(0, MAX_CHARS);
          if (!text) return Response.json({ error: "empty_text" }, { status: 400 });
          const voice = (body.voice ?? "Kore").replace(/[^A-Za-z]/g, "") || "Kore";

          const gatewayResponse = await fetch(`${GATEWAY_URL}/v1/audio/speech`, {
            method: "POST",
            headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
            body: JSON.stringify({
              model: TTS_MODEL,
              contents: [{ role: "user", parts: [{ text }] }],
              generationConfig: {
                responseModalities: ["AUDIO"],
                speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } },
              },
              stream_format: "audio",
            }),
            signal: request.signal,
          });

          if (!gatewayResponse.ok || !gatewayResponse.body) {
            const message = await gatewayResponse.text().catch(() => "");
            console.error("tts upstream failed", gatewayResponse.status, message.slice(0, 300));
            return Response.json({ error: "tts_failed" }, { status: 502 });
          }

          const headers = new Headers();
          headers.set("Content-Type", gatewayResponse.headers.get("content-type") ?? "audio/wav");
          headers.set("Cache-Control", "no-store");
          return new Response(gatewayResponse.body, { status: 200, headers });
        } catch (error) {
          if (error instanceof DOMException && error.name === "AbortError") {
            return new Response(null, { status: 499 });
          }
          console.error("tts failed", error);
          return Response.json({ error: "tts_failed" }, { status: 500 });
        }
      },
    },
  },
});
