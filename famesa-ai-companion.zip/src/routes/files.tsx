import { useRef } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, FileIcon, FolderOpen, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";

import { AppShell, RequireAuth } from "@/components/app-shell";
import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-context";

export const Route = createFileRoute("/files")({
  head: () => ({
    meta: [
      { title: "Dosyalarım — FAMESA AI" },
      { name: "description", content: "FAMESA AI'a yüklediğin görsel, video, ses ve belgeleri yönet." },
      { property: "og:title", content: "Dosyalarım — FAMESA AI" },
      { property: "og:description", content: "FAMESA AI dosya yönetimi." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: FilesPage,
});

interface FileRow {
  id: string;
  name: string;
  mime_type: string;
  size_bytes: number;
  storage_path: string;
  created_at: string;
}

function FilesPage() {
  return (
    <RequireAuth>
      <AppShell>
        <Files />
      </AppShell>
    </RequireAuth>
  );
}

function formatSize(bytes: number) {
  if (bytes > 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  if (bytes > 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${bytes} B`;
}

function Files() {
  const { t, user } = useApp();
  const queryClient = useQueryClient();
  const inputRef = useRef<HTMLInputElement>(null);

  const { data: files = [] } = useQuery({
    queryKey: ["files", user?.id],
    enabled: !!user,
    queryFn: async (): Promise<FileRow[]> => {
      const { data, error } = await supabase
        .from("files")
        .select("id, name, mime_type, size_bytes, storage_path, created_at")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as FileRow[];
    },
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["files", user?.id] });

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const path = `${user!.id}/${crypto.randomUUID()}-${file.name}`;
      const { error: uploadError } = await supabase.storage.from("user-files").upload(path, file);
      if (uploadError) throw uploadError;
      const { error } = await supabase.from("files").insert({
        user_id: user!.id,
        name: file.name,
        mime_type: file.type || "application/octet-stream",
        size_bytes: file.size,
        storage_path: path,
      });
      if (error) throw error;
    },
    onSuccess: invalidate,
    onError: () => toast.error(t("files.uploadError")),
  });

  const deleteMutation = useMutation({
    mutationFn: async (row: FileRow) => {
      await supabase.storage.from("user-files").remove([row.storage_path]);
      const { error } = await supabase.from("files").delete().eq("id", row.id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const download = async (row: FileRow) => {
    const { data, error } = await supabase.storage.from("user-files").createSignedUrl(row.storage_path, 120);
    if (error || !data) {
      toast.error(t("common.error"));
      return;
    }
    window.open(data.signedUrl, "_blank");
  };

  return (
    <div className="mx-auto max-w-2xl px-4 py-8 sm:px-8">
      <div className="fade-up flex items-center justify-between">
        <div className="flex items-center gap-3">
          <FolderOpen className="h-6 w-6 text-primary" />
          <h1 className="font-display text-2xl font-bold text-foreground">{t("files.title")}</h1>
        </div>
        <button
          onClick={() => inputRef.current?.click()}
          className="flex items-center gap-2 rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-transform hover:scale-105"
        >
          <Upload className="h-4 w-4" />
          {t("files.upload")}
        </button>
        <input
          ref={inputRef}
          type="file"
          className="hidden"
          accept="image/*,video/*,audio/*,.pdf,.txt,.md"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) uploadMutation.mutate(file);
            e.target.value = "";
          }}
        />
      </div>

      <div className="mt-6 space-y-2">
        {files.map((file) => (
          <div key={file.id} className="glass-panel fade-up flex items-center gap-3 px-4 py-3">
            <FileIcon className="h-5 w-5 shrink-0 text-primary" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm text-foreground">{file.name}</p>
              <p className="font-mono text-[10px] tracking-wider text-muted-foreground">
                {formatSize(file.size_bytes)} · {new Date(file.created_at).toLocaleDateString()}
              </p>
            </div>
            <button aria-label="download" onClick={() => void download(file)} className="text-muted-foreground hover:text-foreground">
              <Download className="h-4 w-4" />
            </button>
            <button
              aria-label={t("common.delete")}
              onClick={() => deleteMutation.mutate(file)}
              className="text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
        {files.length === 0 && (
          <div className="glass-panel fade-up flex flex-col items-center gap-3 px-6 py-14 text-center">
            <FolderOpen className="h-10 w-10 text-primary/50" />
            <p className="text-sm text-muted-foreground">{t("files.empty")}</p>
          </div>
        )}
      </div>
    </div>
  );
}
