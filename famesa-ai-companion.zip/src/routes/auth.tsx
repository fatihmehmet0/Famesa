import { useState } from "react";
import { createFileRoute, Navigate, useNavigate } from "@tanstack/react-router";
import { Lock } from "lucide-react";
import { toast } from "sonner";

import logoUrl from "@/assets/famesa-logo.png";
import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-context";

// Password-only entrance: a single owner account lives behind the scenes,
// so the user only ever types their personal password.
const OWNER_EMAIL = "sahip@famesa.local";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Giriş — FAMESA AI" },
      { name: "description", content: "FAMESA AI kişisel şifrenle giriş yap." },
      { property: "og:title", content: "Giriş — FAMESA AI" },
      { property: "og:description", content: "FAMESA AI kişisel şifrenle giriş yap." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { t, session, loading } = useApp();
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  if (!loading && session) return <Navigate to="/" />;

  const handleSubmit = async () => {
    setBusy(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email: OWNER_EMAIL, password });
      if (!error) {
        void navigate({ to: "/" });
        return;
      }
      // First-ever entry creates the owner account (email confirmation is off).
      const { data, error: signUpError } = await supabase.auth.signUp({ email: OWNER_EMAIL, password });
      if (signUpError || !data.session) throw new Error(t("auth.wrongPassword"));
      void navigate({ to: "/" });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : t("common.error"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="ambient-field" />
      <div className="glass-panel-strong fade-up w-full max-w-sm p-8">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <img src={logoUrl} alt="FAMESA AI" className="h-16 w-16 drop-shadow-[0_0_20px_var(--color-glow)]" width={1024} height={1024} />
          <div className="font-display text-2xl font-bold text-foreground">
            FAMESA <span className="text-primary text-glow">AI</span>
          </div>
          <p className="text-sm text-muted-foreground">{t("auth.tagline")}</p>
        </div>

        <div className="space-y-3">
          <div className="relative">
            <Lock className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="password"
              autoFocus
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={t("auth.password")}
              onKeyDown={(e) => e.key === "Enter" && void handleSubmit()}
              className="glass-panel w-full py-3 pl-11 pr-4 text-sm text-foreground outline-none placeholder:text-muted-foreground focus:ring-1 focus:ring-ring"
            />
          </div>
          <button
            disabled={busy || !password}
            onClick={() => void handleSubmit()}
            className="w-full rounded-xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.02] active:scale-[0.98] disabled:opacity-40"
          >
            {t("auth.enter")}
          </button>
          <p className="pt-1 text-center text-xs text-muted-foreground">{t("auth.passwordHint")}</p>
        </div>
      </div>
    </div>
  );
}
