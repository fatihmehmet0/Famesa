import { createFileRoute } from "@tanstack/react-router";
import { Share2 } from "lucide-react";
import { toast } from "sonner";

import { AppShell, RequireAuth } from "@/components/app-shell";
import { useApp } from "@/lib/app-context";

export const Route = createFileRoute("/social")({
  head: () => ({
    meta: [
      { title: "Sosyal Hesaplar — FAMESA AI" },
      { name: "description", content: "Sosyal medya hesaplarını resmi API izinleriyle FAMESA AI'a bağla." },
      { property: "og:title", content: "Sosyal Hesaplar — FAMESA AI" },
      { property: "og:description", content: "Sosyal medya entegrasyon merkezi." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SocialPage,
});

const PLATFORMS = [
  { id: "instagram", label: "Instagram", note: "Takipçi, mesaj ve yorum bildirimleri resmi Graph API kapsamında mümkün." },
  { id: "facebook", label: "Facebook", note: "Sayfa bildirimleri resmi Graph API kapsamında mümkün." },
  { id: "tiktok", label: "TikTok", note: "Resmi TikTok API izinleri gerektirir." },
  { id: "x", label: "X", note: "Resmi X API v2 izinleri gerektirir." },
  { id: "youtube", label: "YouTube", note: "Kanal yorumları ve abone verileri resmi YouTube Data API kapsamında mümkün." },
] as const;

function SocialPage() {
  return (
    <RequireAuth>
      <AppShell>
        <Social />
      </AppShell>
    </RequireAuth>
  );
}

function Social() {
  const { t } = useApp();

  return (
    <div className="mx-auto max-w-2xl px-4 py-8 sm:px-8">
      <div className="fade-up flex items-center gap-3">
        <Share2 className="h-6 w-6 text-primary" />
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">{t("social.title")}</h1>
          <p className="text-sm text-muted-foreground">{t("social.subtitle")}</p>
        </div>
      </div>

      <div className="mt-6 space-y-2">
        {PLATFORMS.map((platform, i) => (
          <div key={platform.id} className="glass-panel fade-up px-4 py-4" style={{ animationDelay: `${i * 0.05}s` }}>
            <div className="flex items-center justify-between">
              <span className="font-display text-sm font-semibold text-foreground">{platform.label}</span>
              <button
                onClick={() => toast.message(t("social.needsSetup"))}
                className="rounded-xl border border-border px-4 py-1.5 text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground"
              >
                {t("social.connect")}
              </button>
            </div>
            <p className="mt-1.5 text-xs text-muted-foreground">{platform.note}</p>
            <p className="mt-2 font-mono text-[9px] tracking-widest text-primary/60">OAUTH · OFFICIAL API ONLY</p>
          </div>
        ))}
      </div>

      <div className="glass-panel fade-up mt-6 px-4 py-4 text-xs leading-relaxed text-muted-foreground" style={{ animationDelay: "0.3s" }}>
        {t("social.needsSetup")} {t("social.notAvailable")}
      </div>
    </div>
  );
}
