import { useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Mic, MicOff, Phone, PhoneOff, Play } from "lucide-react";

import { AppShell, RequireAuth } from "@/components/app-shell";
import { useLiveVoice, type LiveEvent } from "@/hooks/use-live-voice";
import { useApp } from "@/lib/app-context";

export const Route = createFileRoute("/voice")({
  head: () => ({
    meta: [
      { title: "Sesli Sohbet — FAMESA AI" },
      { name: "description", content: "FAMESA AI ile gerçek zamanlı, çift yönlü sesli sohbet: konuş, dinle, kesintisiz diyalog." },
      { property: "og:title", content: "Sesli Sohbet — FAMESA AI" },
      { property: "og:description", content: "FAMESA AI ile gerçek zamanlı sesli sohbet." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: VoicePage,
});

type OrbState = "idle" | "listening" | "processing" | "speaking";
type Caption = { role: "user" | "assistant"; text: string };

function VoicePage() {
  return (
    <RequireAuth>
      <AppShell>
        <VoiceSession />
      </AppShell>
    </RequireAuth>
  );
}

function VoiceSession() {
  const { t, settings } = useApp();
  const [captions, setCaptions] = useState<Caption[]>([]);
  const [speaking, setSpeaking] = useState(false);
  const [seconds, setSeconds] = useState<number | null>(null);
  const speakTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const call = useLiveVoice({
    onEvent: (event: LiveEvent) => {
      if (event.type === "session.input_transcript.delta" || event.type === "session.output_transcript.delta") {
        const role: Caption["role"] = event.type === "session.input_transcript.delta" ? "user" : "assistant";
        const delta = typeof event["delta"] === "string" ? (event["delta"] as string) : "";
        if (!delta.trim()) return;
        if (role === "assistant") {
          setSpeaking(true);
          clearTimeout(speakTimer.current);
          speakTimer.current = setTimeout(() => setSpeaking(false), 1500);
        }
        setCaptions((prev) => {
          const last = prev[prev.length - 1];
          const next = last && last.role === role ? [...prev.slice(0, -1), { role, text: last.text + delta }] : [...prev, { role, text: delta }];
          return next.slice(-10);
        });
      }
      if (event.type === "session.usage.updated" || event.type === "session.closed") {
        const reported = event.usage?.seconds;
        if (typeof reported === "number" && Number.isFinite(reported) && reported >= 0) {
          setSeconds(Math.max(15, Math.round(reported)));
        }
      }
      if (event.type === "app.closed") setSpeaking(false);
    },
  });

  const orbState: OrbState =
    call.status === "connecting" ? "processing" : call.status === "connected" ? (speaking ? "speaking" : "listening") : "idle";
  const inCall = call.status === "connecting" || call.status === "connected" || call.status === "stopping";

  const lastUser = [...captions].reverse().find((c) => c.role === "user");
  const lastAssistant = [...captions].reverse().find((c) => c.role === "assistant");

  return (
    <div className="mx-auto flex min-h-[calc(100vh-4rem)] max-w-xl flex-col items-center justify-center px-4 py-10 lg:min-h-screen">
      <h1 className="font-display text-xl font-bold text-foreground">{t("voice.title")}</h1>

      {/* Live audio playback element — must stay mounted for the whole call */}
      <audio ref={call.audioRef} autoPlay className="hidden" />

      <div className="relative mt-12 flex items-center justify-center">
        <div className="voice-orb h-44 w-44 sm:h-56 sm:w-56" data-state={orbState} />
        <button
          aria-label={inCall ? "end" : "start"}
          disabled={call.status === "connecting" || call.status === "stopping"}
          onClick={() => (inCall ? call.stop() : call.start())}
          className="glass-panel-strong absolute flex h-16 w-16 items-center justify-center rounded-full text-foreground transition-transform hover:scale-110 active:scale-95 disabled:opacity-50"
        >
          {inCall ? <PhoneOff className="h-6 w-6 text-destructive" /> : <Phone className="h-6 w-6 text-primary" />}
        </button>
      </div>

      <div className="mt-10 font-mono text-[11px] tracking-[0.35em] text-primary">
        {call.status === "idle" && t("voice.start")}
        {call.status === "connecting" && t("voice.connecting")}
        {call.status === "connected" && (speaking ? t("voice.speaking") : t("voice.live"))}
        {call.status === "stopping" && t("voice.processing")}
        {call.status === "closed" && t("voice.start")}
      </div>

      {call.error && <p className="mt-4 max-w-sm text-center text-sm text-destructive">{call.error}</p>}

      {call.playbackBlocked && (
        <button
          onClick={() => call.resumePlayback()}
          className="mt-4 flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-transform hover:scale-105"
        >
          <Play className="h-4 w-4" />
          {t("voice.resume")}
        </button>
      )}

      {inCall && (
        <div className="mt-6 flex items-center gap-3">
          <button
            onClick={() => call.setMuted(!call.muted)}
            className="glass-panel flex items-center gap-2 px-4 py-2 text-xs text-foreground transition-transform hover:scale-105"
          >
            {call.muted ? <MicOff className="h-4 w-4 text-destructive" /> : <Mic className="h-4 w-4 text-primary" />}
            {call.muted ? t("voice.unmute") : t("voice.mute")}
          </button>
          {seconds !== null && (
            <span className="font-mono text-[11px] tracking-widest text-muted-foreground">
              {seconds} {t("voice.seconds")}
            </span>
          )}
        </div>
      )}

      {(lastUser || lastAssistant) && (
        <div className="mt-10 w-full space-y-3">
          {lastUser && (
            <div className="glass-panel fade-up px-4 py-3">
              <div className="font-mono text-[10px] tracking-[0.25em] text-muted-foreground">{t("voice.you")}</div>
              <p className="mt-1 text-sm text-foreground">{lastUser.text}</p>
            </div>
          )}
          {lastAssistant && (
            <div className="glass-panel-strong fade-up px-4 py-3">
              <div className="font-mono text-[10px] tracking-[0.25em] text-primary">{settings.ai_name}</div>
              <p className="mt-1 text-sm text-foreground">{lastAssistant.text}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
