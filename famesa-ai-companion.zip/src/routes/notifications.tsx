import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Bell, CheckCheck, Trash2 } from "lucide-react";

import { AppShell, RequireAuth } from "@/components/app-shell";
import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-context";

export const Route = createFileRoute("/notifications")({
  head: () => ({
    meta: [
      { title: "Bildirimler — FAMESA AI" },
      { name: "description", content: "FAMESA AI bildirim merkezi: AI, sosyal, sistem ve sohbet bildirimleri." },
      { property: "og:title", content: "Bildirimler — FAMESA AI" },
      { property: "og:description", content: "FAMESA AI bildirim merkezi." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: NotificationsPage,
});

interface NotificationRow {
  id: string;
  category: string;
  title: string;
  body: string | null;
  read: boolean;
  created_at: string;
}

const CATEGORIES = ["all", "ai", "social", "system", "security", "chat"] as const;

function NotificationsPage() {
  return (
    <RequireAuth>
      <AppShell>
        <Notifications />
      </AppShell>
    </RequireAuth>
  );
}

function Notifications() {
  const { t, user } = useApp();
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<(typeof CATEGORIES)[number]>("all");

  const { data: notifications = [] } = useQuery({
    queryKey: ["notifications", user?.id],
    enabled: !!user,
    queryFn: async (): Promise<NotificationRow[]> => {
      const { data, error } = await supabase
        .from("notifications")
        .select("id, category, title, body, read, created_at")
        .order("created_at", { ascending: false })
        .limit(100);
      if (error) throw error;
      return data as NotificationRow[];
    },
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["notifications", user?.id] });

  const markRead = useMutation({
    mutationFn: async (id: string) => {
      await supabase.from("notifications").update({ read: true }).eq("id", id);
    },
    onSuccess: invalidate,
  });
  const markAll = useMutation({
    mutationFn: async () => {
      await supabase.from("notifications").update({ read: true }).eq("user_id", user!.id);
    },
    onSuccess: invalidate,
  });
  const clearAll = useMutation({
    mutationFn: async () => {
      await supabase.from("notifications").delete().eq("user_id", user!.id);
    },
    onSuccess: invalidate,
  });

  const filtered = filter === "all" ? notifications : notifications.filter((n) => n.category === filter);

  return (
    <div className="mx-auto max-w-2xl px-4 py-8 sm:px-8">
      <div className="fade-up flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Bell className="h-6 w-6 text-primary" />
          <h1 className="font-display text-2xl font-bold text-foreground">{t("notif.title")}</h1>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => markAll.mutate()}
            className="glass-panel flex items-center gap-1.5 px-3 py-2 text-xs text-muted-foreground hover:text-foreground"
          >
            <CheckCheck className="h-3.5 w-3.5" />
            {t("notif.markAll")}
          </button>
          <button
            onClick={() => clearAll.mutate()}
            className="glass-panel flex items-center gap-1.5 px-3 py-2 text-xs text-muted-foreground hover:text-destructive"
          >
            <Trash2 className="h-3.5 w-3.5" />
            {t("notif.clearAll")}
          </button>
        </div>
      </div>

      <div className="fade-up mt-5 flex flex-wrap gap-1.5" style={{ animationDelay: "0.06s" }}>
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`rounded-full px-3.5 py-1.5 text-xs transition-all ${
              filter === cat ? "bg-primary text-primary-foreground" : "glass-panel text-muted-foreground hover:text-foreground"
            }`}
          >
            {t(`notif.${cat}` as Parameters<typeof t>[0])}
          </button>
        ))}
      </div>

      <div className="mt-4 space-y-2">
        {filtered.map((notification) => (
          <button
            key={notification.id}
            onClick={() => !notification.read && markRead.mutate(notification.id)}
            className={`glass-panel fade-up block w-full px-4 py-3 text-left transition-all ${
              notification.read ? "opacity-55" : "glow-edge"
            }`}
          >
            <div className="flex items-center gap-2">
              {!notification.read && <span className="h-1.5 w-1.5 rounded-full bg-primary" />}
              <span className="text-sm font-medium text-foreground">{notification.title}</span>
              <span className="ml-auto font-mono text-[9px] tracking-widest text-muted-foreground">
                {notification.category.toUpperCase()}
              </span>
            </div>
            {notification.body && <p className="mt-1 text-xs text-muted-foreground">{notification.body}</p>}
            <p className="mt-1 font-mono text-[9px] text-muted-foreground/60">
              {new Date(notification.created_at).toLocaleString()}
            </p>
          </button>
        ))}
        {filtered.length === 0 && (
          <div className="glass-panel fade-up flex flex-col items-center gap-3 px-6 py-14 text-center">
            <Bell className="h-10 w-10 text-primary/50" />
            <p className="text-sm text-muted-foreground">{t("notif.empty")}</p>
          </div>
        )}
      </div>
    </div>
  );
}
