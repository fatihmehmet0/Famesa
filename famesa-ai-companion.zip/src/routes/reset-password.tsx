import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";

import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-context";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Şifre Sıfırlama — FAMESA AI" },
      { name: "description", content: "FAMESA AI hesabın için yeni şifre belirle." },
      { property: "og:title", content: "Şifre Sıfırlama — FAMESA AI" },
      { property: "og:description", content: "FAMESA AI hesabın için yeni şifre belirle." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const { t } = useApp();
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    // Recovery links arrive with type=recovery in the URL hash.
    const hash = new URLSearchParams(window.location.hash.slice(1));
    if (hash.get("type") === "recovery") setReady(true);
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") setReady(true);
    });
    return () => subscription.unsubscribe();
  }, []);

  const submit = async () => {
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(t("set.saved"));
    void navigate({ to: "/" });
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="ambient-field" />
      <div className="glass-panel-strong fade-up w-full max-w-sm p-8">
        <h1 className="font-display text-xl font-bold text-foreground">{t("auth.newPassword")}</h1>
        {ready ? (
          <div className="mt-4 space-y-3">
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={t("auth.newPassword")}
              className="glass-panel w-full px-4 py-3 text-sm text-foreground outline-none placeholder:text-muted-foreground focus:ring-1 focus:ring-ring"
            />
            <button
              disabled={busy || password.length < 6}
              onClick={() => void submit()}
              className="w-full rounded-xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground disabled:opacity-40"
            >
              {t("auth.resetCta")}
            </button>
          </div>
        ) : (
          <p className="mt-3 text-sm text-muted-foreground">{t("common.loading")}</p>
        )}
      </div>
    </div>
  );
}
