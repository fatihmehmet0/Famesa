import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Bell, Brain, Camera, Cpu, FolderOpen, Image as ImageIcon, Map, Mic, Send, Settings, Share2, Video } from "lucide-react";

import { AppShell, RequireAuth } from "@/components/app-shell";
import { useApp } from "@/lib/app-context";
import { useConversations } from "@/hooks/use-conversations";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FAMESA AI — Kişisel Yapay Zeka Asistanı" },
      {
        name: "description",
        content: "FAMESA AI ana sayfası: yeni sohbet başlat, kamera, sesli sohbet, hafıza ve AI modellerine hızlı eriş.",
      },
      { property: "og:title", content: "FAMESA AI — Kişisel Yapay Zeka Asistanı" },
      { property: "og:description", content: "Metin, görsel, ses ve video anlayan; hafızalı, premium kişisel AI asistanı." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <RequireAuth>
      <AppShell>
        <Home />
      </AppShell>
    </RequireAuth>
  );
}

function Home() {
  const { t, profile } = useApp();
  const { conversations, createConversation } = useConversations();
  const navigate = useNavigate();
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);

  const startChat = async (text?: string) => {
    if (busy) return;
    setBusy(true);
    try {
      const conversation = await createConversation(t("chat.untitled"));
      if (text?.trim()) sessionStorage.setItem("famesa:pending-message", text.trim());
      void navigate({ to: "/chat/$threadId", params: { threadId: conversation.id } });
    } finally {
      setBusy(false);
    }
  };

  const quickActions = [
    { icon: Mic, label: t("nav.voice"), to: "/voice" },
    { icon: Map, label: t("nav.map"), to: "/map" },
    { icon: Camera, label: t("nav.camera"), to: "/camera" },
    { icon: ImageIcon, label: t("home.quick.image"), action: () => void startChat() },
    { icon: Video, label: t("home.quick.video"), action: () => void startChat() },
    { icon: Brain, label: t("nav.memories"), to: "/memories" },
    { icon: Cpu, label: t("nav.models"), to: "/models" },
    { icon: FolderOpen, label: t("nav.files"), to: "/files" },
    { icon: Bell, label: t("nav.notifications"), to: "/notifications" },
    { icon: Share2, label: t("nav.social"), to: "/social" },
    { icon: Settings, label: t("nav.settings"), to: "/settings" },
  ];

  return (
    <div className="mx-auto flex min-h-[calc(100vh-4rem)] max-w-3xl flex-col px-4 py-10 sm:px-8 lg:min-h-screen lg:justify-center">
      <div className="fade-up">
        <h1 className="font-display text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
          {t("home.greeting", { name: profile?.display_name ?? profile?.username ?? "" })}
        </h1>
        <p className="mt-3 text-lg text-muted-foreground">{t("home.subtitle")}</p>
      </div>

      <div className="glass-panel-strong glow-edge fade-up mt-8 flex items-end gap-2 p-2" style={{ animationDelay: "0.1s" }}>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              void startChat(input);
            }
          }}
          placeholder={t("home.placeholder")}
          rows={2}
          className="max-h-40 flex-1 resize-none bg-transparent px-3 py-2.5 text-[15px] text-foreground outline-none placeholder:text-muted-foreground"
        />
        <button
          aria-label={t("chat.send")}
          disabled={!input.trim() || busy}
          onClick={() => void startChat(input)}
          className="rounded-xl bg-primary p-3 text-primary-foreground transition-transform hover:scale-105 active:scale-95 disabled:opacity-40"
        >
          <Send className="h-5 w-5" />
        </button>
      </div>

      <div className="fade-up mt-6 grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-6" style={{ animationDelay: "0.18s" }}>
        {quickActions.map((action) => (
          <button
            key={action.label}
            onClick={() => (action.to ? void navigate({ to: action.to }) : action.action?.())}
            className="glass-panel flex flex-col items-center gap-2 px-2 py-4 text-xs text-muted-foreground transition-all hover:scale-[1.03] hover:text-foreground"
          >
            <action.icon className="h-5 w-5 text-primary" />
            {action.label}
          </button>
        ))}
      </div>

      {conversations.length > 0 && (
        <div className="fade-up mt-10" style={{ animationDelay: "0.26s" }}>
          <h2 className="mb-3 font-mono text-[11px] tracking-[0.3em] text-muted-foreground">{t("home.recent")}</h2>
          <div className="grid gap-2 sm:grid-cols-2">
            {conversations.slice(0, 6).map((conversation) => (
              <button
                key={conversation.id}
                onClick={() => void navigate({ to: "/chat/$threadId", params: { threadId: conversation.id } })}
                className="glass-panel truncate px-4 py-3 text-left text-sm text-foreground transition-transform hover:scale-[1.01]"
              >
                {conversation.title}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
