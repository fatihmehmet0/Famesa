import { lazy, Suspense } from "react";
import { ClientOnly, createFileRoute } from "@tanstack/react-router";

import { AppShell, BootScreen, RequireAuth } from "@/components/app-shell";

// maplibre-gl is browser-only: it loads lazily and renders client-side only.
const FamesaMap = lazy(() => import("@/components/map/famesa-map"));

export const Route = createFileRoute("/map")({
  head: () => ({
    meta: [
      { title: "FAMESA Map — Konum ve Rota" },
      { name: "description", content: "FAMESA temalı canlı harita: konumunu paylaş, hedef seç, mesafe, hız ve kalan süre analizi." },
      { property: "og:title", content: "FAMESA Map — Konum ve Rota" },
      { property: "og:description", content: "Canlı konum, hedef seçimi ve rota analizi — FAMESA temasında." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: MapPage,
});

function MapPage() {
  return (
    <RequireAuth>
      <AppShell>
        <ClientOnly fallback={<BootScreen />}>
          <Suspense fallback={<BootScreen />}>
            <FamesaMap />
          </Suspense>
        </ClientOnly>
      </AppShell>
    </RequireAuth>
  );
}
