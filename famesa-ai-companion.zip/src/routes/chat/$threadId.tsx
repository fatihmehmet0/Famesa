import { createFileRoute, useParams } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import type { UIMessage } from "ai";

import { AppShell, BootScreen, RequireAuth } from "@/components/app-shell";
import { ChatWindow } from "@/components/chat/chat-window";
import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-context";

export const Route = createFileRoute("/chat/$threadId")({
  head: () => ({
    meta: [
      { title: "Sohbet — FAMESA AI" },
      { name: "description", content: "FAMESA AI ile sohbet et: metin, görsel, video ve dosya analizi." },
      { property: "og:title", content: "Sohbet — FAMESA AI" },
      { property: "og:description", content: "FAMESA AI ile sohbet et: metin, görsel, video ve dosya analizi." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ChatPage,
});

interface MessageRow {
  id: string;
  sdk_id: string | null;
  role: string;
  parts: unknown;
}

function ChatPage() {
  const { threadId } = useParams({ from: "/chat/$threadId" });
  const { user } = useApp();

  const { data, isLoading } = useQuery({
    queryKey: ["messages", threadId],
    enabled: !!user,
    queryFn: async (): Promise<UIMessage[]> => {
      const { data: rows, error } = await supabase
        .from("messages")
        .select("id, sdk_id, role, parts")
        .eq("conversation_id", threadId)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (rows as MessageRow[]).map((row) => ({
        id: row.sdk_id ?? row.id,
        role: row.role as UIMessage["role"],
        parts: row.parts as UIMessage["parts"],
      }));
    },
  });

  return (
    <RequireAuth>
      <AppShell>
        {isLoading ? <BootScreen /> : <ChatWindow key={threadId} threadId={threadId} initialMessages={data ?? []} />}
      </AppShell>
    </RequireAuth>
  );
}
