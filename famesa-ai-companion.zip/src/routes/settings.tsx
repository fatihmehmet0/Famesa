import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Settings as SettingsIcon } from "lucide-react";
import { toast } from "sonner";

import { AppShell, RequireAuth } from "@/components/app-shell";
import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-context";
import { LANGUAGES, type Language } from "@/lib/i18n";
import { AI_MODELS, AI_PERSONALITIES, THEMES, TTS_VOICES, type ThemeId } from "@/lib/settings";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Ayarlar — FAMESA AI" },
      { name: "description", content: "FAMESA AI ayarları: profil, AI kişiliği, tema, dil, ses, hafıza ve gizlilik." },
      { property: "og:title", content: "Ayarlar — FAMESA AI" },
      { property: "og:description", content: "FAMESA AI ayarları." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  return (
    <RequireAuth>
      <AppShell>
        <Settings />
      </AppShell>
    </RequireAuth>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="glass-panel fade-up p-5">
      <h2 className="mb-4 font-mono text-[11px] tracking-[0.3em] text-primary">{title}</h2>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3">
      <span className="text-sm text-foreground">{label}</span>
      {children}
    </div>
  );
}

function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      role="switch"
      aria-checked={value}
      onClick={() => onChange(!value)}
      className={`relative h-6 w-11 rounded-full transition-colors ${value ? "bg-primary" : "bg-secondary"}`}
    >
      <span
        className={`absolute top-0.5 h-5 w-5 rounded-full bg-foreground transition-all ${value ? "left-[22px]" : "left-0.5"}`}
      />
    </button>
  );
}

function Settings() {
  const { t, user, profile, settings, updateSettings, refreshProfile } = useApp();
  const navigate = useNavigate();
  const [name, setName] = useState(profile?.display_name ?? "");

  const saveProfile = async () => {
    if (!user) return;
    await supabase.from("profiles").update({ display_name: name.trim() || null }).eq("id", user.id);
    await refreshProfile();
    toast.success(t("set.saved"));
  };

  const selectClass =
    "glass-panel px-3 py-2 text-sm text-foreground outline-none [&>option]:bg-popover";

  return (
    <div className="mx-auto max-w-2xl space-y-4 px-4 py-8 sm:px-8">
      <div className="fade-up flex items-center gap-3">
        <SettingsIcon className="h-6 w-6 text-primary" />
        <h1 className="font-display text-2xl font-bold text-foreground">{t("set.title")}</h1>
      </div>

      <Section title={t("set.profile")}>
        <Row label={t("set.name")}>
          <div className="flex gap-2">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="glass-panel px-3 py-2 text-sm text-foreground outline-none"
            />
            <button onClick={() => void saveProfile()} className="rounded-xl bg-primary px-4 py-2 text-xs font-medium text-primary-foreground">
              {t("set.save")}
            </button>
          </div>
        </Row>
        <Row label={t("auth.email")}>
          <span className="text-sm text-muted-foreground">{user?.email}</span>
        </Row>
      </Section>

      <Section title={t("set.ai")}>
        <Row label={t("set.aiName")}>
          <input
            value={settings.ai_name}
            onChange={(e) => void updateSettings({ ai_name: e.target.value })}
            className="glass-panel w-40 px-3 py-2 text-sm text-foreground outline-none"
          />
        </Row>
        <Row label={t("set.personality")}>
          <select
            value={settings.ai_personality}
            onChange={(e) => void updateSettings({ ai_personality: e.target.value })}
            className={selectClass}
          >
            {AI_PERSONALITIES.map((p) => (
              <option key={p} value={p} className="capitalize">
                {p}
              </option>
            ))}
          </select>
        </Row>
        <Row label={t("set.responseLength")}>
          <select
            value={settings.response_length}
            onChange={(e) => void updateSettings({ response_length: e.target.value as typeof settings.response_length })}
            className={selectClass}
          >
            <option value="short">kısa</option>
            <option value="balanced">dengeli</option>
            <option value="detailed">detaylı</option>
          </select>
        </Row>
        <Row label={t("set.defaultModel")}>
          <select
            value={settings.default_model}
            onChange={(e) => void updateSettings({ default_model: e.target.value })}
            className={selectClass}
          >
            {AI_MODELS.map((m) => (
              <option key={m.id} value={m.id}>
                {m.label}
              </option>
            ))}
          </select>
        </Row>
      </Section>

      <Section title={t("set.appearance")}>
        <div className="grid gap-2 sm:grid-cols-3">
          {THEMES.map((theme) => (
            <button
              key={theme.id}
              onClick={() => void updateSettings({ theme: theme.id as ThemeId })}
              className={`glass-panel px-3 py-3 text-left transition-all ${settings.theme === theme.id ? "glow-edge" : ""}`}
            >
              <div className="font-display text-xs font-semibold text-foreground">{t(theme.nameKey)}</div>
              <div className="mt-0.5 text-[10px] text-muted-foreground">{t(theme.descKey)}</div>
            </button>
          ))}
        </div>
        <Row label={t("set.fontSize")}>
          <select
            value={settings.font_size}
            onChange={(e) => void updateSettings({ font_size: e.target.value as typeof settings.font_size })}
            className={selectClass}
          >
            <option value="small">S</option>
            <option value="medium">M</option>
            <option value="large">L</option>
          </select>
        </Row>
        <Row label={t("set.animations")}>
          <Toggle value={settings.animations_enabled} onChange={(v) => void updateSettings({ animations_enabled: v })} />
        </Row>
        <Row label={t("set.glass")}>
          <select
            value={settings.glass_intensity}
            onChange={(e) => void updateSettings({ glass_intensity: e.target.value as typeof settings.glass_intensity })}
            className={selectClass}
          >
            <option value="low">low</option>
            <option value="medium">medium</option>
            <option value="high">high</option>
          </select>
        </Row>
      </Section>

      <Section title={t("set.voice")}>
        <Row label={t("set.aiVoice")}>
          <select
            value={settings.tts_voice}
            onChange={(e) => void updateSettings({ tts_voice: e.target.value })}
            className={selectClass}
          >
            {TTS_VOICES.map((v) => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </select>
        </Row>
        <Row label={t("set.voiceSpeed")}>
          <input
            type="range"
            min={0.5}
            max={2}
            step={0.1}
            value={settings.voice_speed}
            onChange={(e) => void updateSettings({ voice_speed: Number(e.target.value) })}
            className="w-40 accent-[var(--color-primary)]"
          />
        </Row>
        <Row label={t("set.autoSpeak")}>
          <Toggle value={settings.auto_speak} onChange={(v) => void updateSettings({ auto_speak: v })} />
        </Row>
      </Section>

      <Section title={t("set.language")}>
        <Row label={t("set.appLanguage")}>
          <select
            value={settings.language}
            onChange={(e) => void updateSettings({ language: e.target.value as Language })}
            className={selectClass}
          >
            {LANGUAGES.map((lang) => (
              <option key={lang.id} value={lang.id}>
                {lang.label}
              </option>
            ))}
          </select>
        </Row>
      </Section>

      <Section title={t("set.memory")}>
        <Row label={t("set.manageMemory")}>
          <button
            onClick={() => void navigate({ to: "/memories" })}
            className="rounded-xl border border-border px-4 py-2 text-xs text-foreground hover:border-primary/40"
          >
            {t("nav.memories")} →
          </button>
        </Row>
      </Section>

      <Section title={t("set.notifications")}>
        {(["ai", "social", "system", "sounds"] as const).map((key) => {
          const labels = {
            ai: t("set.notifAi"),
            social: t("set.notifSocial"),
            system: t("set.notifSystem"),
            sounds: t("set.notifSounds"),
          };
          return (
            <Row key={key} label={labels[key]}>
              <Toggle
                value={settings.notification_prefs[key] ?? true}
                onChange={(v) =>
                  void updateSettings({ notification_prefs: { ...settings.notification_prefs, [key]: v } })
                }
              />
            </Row>
          );
        })}
      </Section>

      <Section title={t("set.privacy")}>
        <p className="text-xs leading-relaxed text-muted-foreground">{t("set.privacyNote")}</p>
        <div className="border-t border-border pt-3">
          <p className="text-xs text-muted-foreground">{t("set.deleteAccountNote")}</p>
        </div>
      </Section>
    </div>
  );
}
