import { useEffect, useRef, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Camera, SwitchCamera } from "lucide-react";

import { AppShell, RequireAuth } from "@/components/app-shell";
import { useApp } from "@/lib/app-context";
import { useConversations } from "@/hooks/use-conversations";

export const Route = createFileRoute("/camera")({
  head: () => ({
    meta: [
      { title: "Kamera — FAMESA AI" },
      { name: "description", content: "Kameranı bir nesneye veya probleme yönlendir; FAMESA AI analiz etsin." },
      { property: "og:title", content: "Kamera — FAMESA AI" },
      { property: "og:description", content: "Kameranı FAMESA AI'a göster, anında analiz al." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CameraPage,
});

function CameraPage() {
  return (
    <RequireAuth>
      <AppShell>
        <CameraView />
      </AppShell>
    </RequireAuth>
  );
}

function CameraView() {
  const { t } = useApp();
  const navigate = useNavigate();
  const { createConversation } = useConversations();
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [error, setError] = useState(false);
  const [facing, setFacing] = useState<"environment" | "user">("environment");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const start = async () => {
      try {
        streamRef.current?.getTracks().forEach((track) => track.stop());
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: facing, width: { ideal: 1920 }, height: { ideal: 1080 } },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((track) => track.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) videoRef.current.srcObject = stream;
        setError(false);
      } catch {
        if (!cancelled) setError(true);
      }
    };
    void start();
    return () => {
      cancelled = true;
      streamRef.current?.getTracks().forEach((track) => track.stop());
    };
  }, [facing]);

  const capture = async () => {
    const video = videoRef.current;
    if (!video || busy) return;
    setBusy(true);
    try {
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext("2d")!.drawImage(video, 0, 0);
      const dataUrl = canvas.toDataURL("image/jpeg", 0.92);
      sessionStorage.setItem("famesa:pending-image", dataUrl);
      const conversation = await createConversation(t("camera.title"));
      void navigate({ to: "/chat/$threadId", params: { threadId: conversation.id } });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto flex max-w-2xl flex-col px-4 py-6 sm:px-8">
      <h1 className="font-display text-2xl font-bold text-foreground">{t("camera.title")}</h1>
      <p className="mt-1 text-sm text-muted-foreground">{t("camera.hint")}</p>

      <div className="glass-panel-strong glow-edge relative mt-5 overflow-hidden rounded-2xl">
        {error ? (
          <div className="flex aspect-video flex-col items-center justify-center gap-3 text-center">
            <Camera className="h-10 w-10 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">{t("camera.denied")}</p>
          </div>
        ) : (
          <video ref={videoRef} autoPlay playsInline muted className="aspect-video w-full object-cover" />
        )}
        <div className="pointer-events-none absolute inset-0 rounded-2xl border border-primary/20" />
      </div>

      <div className="mt-5 flex items-center justify-center gap-3">
        <button
          aria-label="switch"
          onClick={() => setFacing((f) => (f === "environment" ? "user" : "environment"))}
          className="glass-panel p-3.5 text-foreground transition-transform hover:scale-105"
        >
          <SwitchCamera className="h-5 w-5" />
        </button>
        <button
          disabled={error || busy}
          onClick={() => void capture()}
          className="glow-edge rounded-2xl bg-primary px-8 py-4 font-display text-sm font-bold tracking-widest text-primary-foreground transition-transform hover:scale-105 active:scale-95 disabled:opacity-40"
        >
          {t("camera.show")}
        </button>
      </div>
    </div>
  );
}
