import { createFileRoute } from "@tanstack/react-router";
import { HelpCircle } from "lucide-react";

import { AppShell, RequireAuth } from "@/components/app-shell";
import { useApp } from "@/lib/app-context";

export const Route = createFileRoute("/help")({
  head: () => ({
    meta: [
      { title: "Nasıl Kullanılır? — FAMESA AI" },
      { name: "description", content: "FAMESA AI kullanım rehberi: sohbet, kamera, sesli sohbet, hafıza ve modeller." },
      { property: "og:title", content: "Nasıl Kullanılır? — FAMESA AI" },
      { property: "og:description", content: "FAMESA AI kullanım rehberi." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: HelpPage,
});

const TOPICS = [
  {
    q: "Sohbet nasıl başlatılır?",
    a: "Ana sayfadaki mesaj kutusuna yaz ve gönder — yeni sohbet otomatik oluşur. Kenar menüden 'Yeni Sohbet' ile de başlatabilirsin. Sohbetleri yeniden adlandırabilir, silebilir ve arayabilirsin.",
  },
  {
    q: "Görsel nasıl gönderilir?",
    a: "Sohbet ekranındaki dosya butonuyla görsel yükle. FAMESA görseldeki nesneleri, yazıları (Türkçe karakterler dahil), grafikleri, kod ekran görüntülerini ve belgeleri okuyabilir. 'Bu yazıyı Türkçeye çevir' diyebilirsin.",
  },
  {
    q: "Kamera nasıl kullanılır?",
    a: "Kamera sayfasını aç, kamerayı bir nesneye veya probleme yönlendir ve FAMESA'YA GÖSTER butonuna bas. Görüntü yeni bir sohbete eklenir ve FAMESA analiz eder.",
  },
  {
    q: "Sesli sohbet nasıl açılır?",
    a: "Sesli Sohbet sayfasında ortadaki mikrofon butonuna dokun ve konuş. FAMESA konuşmanı yazıya çevirir, cevaplar ve sesli okur. Bitirmek için 'Konuşmayı kapat' butonunu kullan.",
  },
  {
    q: "Hafıza nasıl kullanılır?",
    a: "Sohbette 'Bunu hatırla: ...' dediğinde FAMESA bilgiyi hafızasına kaydeder. Hafızam sayfasından tüm bilgileri görebilir, düzenleyebilir veya silebilirsin. Hiçbir bilgi sen istemeden kaydedilmez.",
  },
  {
    q: "Model nasıl değiştirilir?",
    a: "AI Modelleri sayfasından OpenAI, Google ve Anthropic modelleri arasından seçim yapabilirsin. Seçtiğin model tüm yeni sohbetlerde varsayılan olur.",
  },
  {
    q: "Video nasıl analiz edilir?",
    a: "Sohbette dosya butonundan video seç. FAMESA videodan kareler çıkarır ve içeriği analiz eder; ekrandaki yazıları okuyabilir, olayları yorumlayabilir.",
  },
  {
    q: "Sosyal hesaplar nasıl bağlanır?",
    a: "Sosyal Hesaplar sayfası desteklenen platformları listeler. Entegrasyonlar yalnızca resmi API'ler ve OAuth izinleri üzerinden çalışır; bir platform veriyi sunmuyorsa bu açıkça belirtilir, sahte veri gösterilmez.",
  },
];

function HelpPage() {
  return (
    <RequireAuth>
      <AppShell>
        <Help />
      </AppShell>
    </RequireAuth>
  );
}

function Help() {
  const { t } = useApp();
  return (
    <div className="mx-auto max-w-2xl px-4 py-8 sm:px-8">
      <div className="fade-up flex items-center gap-3">
        <HelpCircle className="h-6 w-6 text-primary" />
        <h1 className="font-display text-2xl font-bold text-foreground">{t("help.title")}</h1>
      </div>
      <div className="mt-6 space-y-2">
        {TOPICS.map((topic, i) => (
          <details key={topic.q} className="glass-panel fade-up group px-4 py-3" style={{ animationDelay: `${i * 0.04}s` }}>
            <summary className="cursor-pointer text-sm font-medium text-foreground transition-colors group-open:text-primary">
              {topic.q}
            </summary>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{topic.a}</p>
          </details>
        ))}
      </div>
    </div>
  );
}
