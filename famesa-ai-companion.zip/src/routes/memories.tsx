import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Brain, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { AppShell, RequireAuth } from "@/components/app-shell";
import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-context";

export const Route = createFileRoute("/memories")({
  head: () => ({
    meta: [
      { title: "Hafızam — FAMESA AI" },
      { name: "description", content: "FAMESA AI'ın senin hakkında hatırladığı bilgileri görüntüle, düzenle veya sil." },
      { property: "og:title", content: "Hafızam — FAMESA AI" },
      { property: "og:description", content: "FAMESA AI hafıza yönetimi." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: MemoriesPage,
});

interface MemoryRow {
  id: string;
  content: string;
  category: string;
  created_at: string;
}

function MemoriesPage() {
  return (
    <RequireAuth>
      <AppShell>
        <Memories />
      </AppShell>
    </RequireAuth>
  );
}

function Memories() {
  const { t, user } = useApp();
  const queryClient = useQueryClient();
  const [draft, setDraft] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState("");

  const { data: memories = [] } = useQuery({
    queryKey: ["memories", user?.id],
    enabled: !!user,
    queryFn: async (): Promise<MemoryRow[]> => {
      const { data, error } = await supabase
        .from("memories")
        .select("id, content, category, created_at")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as MemoryRow[];
    },
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["memories", user?.id] });

  const addMutation = useMutation({
    mutationFn: async (content: string) => {
      const { error } = await supabase.from("memories").insert({ user_id: user!.id, content, category: "genel" });
      if (error) throw error;
    },
    onSuccess: () => {
      setDraft("");
      void invalidate();
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, content }: { id: string; content: string }) => {
      const { error } = await supabase.from("memories").update({ content }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      setEditingId(null);
      void invalidate();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("memories").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const clearMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("memories").delete().eq("user_id", user!.id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  return (
    <div className="mx-auto max-w-2xl px-4 py-8 sm:px-8">
      <div className="fade-up flex items-center gap-3">
        <Brain className="h-6 w-6 text-primary" />
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">{t("mem.title")}</h1>
          <p className="text-sm text-muted-foreground">{t("mem.subtitle")}</p>
        </div>
      </div>

      <div className="glass-panel fade-up mt-6 flex gap-2 p-2" style={{ animationDelay: "0.08s" }}>
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder={t("mem.placeholder")}
          className="flex-1 bg-transparent px-3 py-2 text-sm text-foreground outline-none placeholder:text-muted-foreground"
          onKeyDown={(e) => e.key === "Enter" && draft.trim() && addMutation.mutate(draft.trim())}
        />
        <button
          disabled={!draft.trim()}
          onClick={() => addMutation.mutate(draft.trim())}
          className="flex items-center gap-2 rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground disabled:opacity-40"
        >
          <Plus className="h-4 w-4" />
          {t("mem.add")}
        </button>
      </div>

      <div className="mt-4 space-y-2">
        {memories.map((memory) => (
          <div key={memory.id} className="glass-panel fade-up flex items-center gap-3 px-4 py-3">
            {editingId === memory.id ? (
              <input
                autoFocus
                value={editDraft}
                onChange={(e) => setEditDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && editDraft.trim()) updateMutation.mutate({ id: memory.id, content: editDraft.trim() });
                  if (e.key === "Escape") setEditingId(null);
                }}
                className="flex-1 rounded-md bg-background/60 px-2 py-1 text-sm text-foreground outline-none ring-1 ring-ring/40"
              />
            ) : (
              <div className="min-w-0 flex-1">
                <p className="text-sm text-foreground">{memory.content}</p>
                <p className="mt-0.5 font-mono text-[10px] tracking-widest text-muted-foreground">
                  {memory.category} · {new Date(memory.created_at).toLocaleDateString()}
                </p>
              </div>
            )}
            {editingId === memory.id ? (
              <button
                onClick={() => editDraft.trim() && updateMutation.mutate({ id: memory.id, content: editDraft.trim() })}
                className="text-xs text-primary"
              >
                {t("common.save")}
              </button>
            ) : (
              <button
                aria-label={t("mem.edit")}
                onClick={() => {
                  setEditingId(memory.id);
                  setEditDraft(memory.content);
                }}
                className="text-muted-foreground hover:text-foreground"
              >
                <Pencil className="h-4 w-4" />
              </button>
            )}
            <button
              aria-label={t("mem.delete")}
              onClick={() => deleteMutation.mutate(memory.id)}
              className="text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}

        {memories.length === 0 && (
          <div className="glass-panel fade-up flex flex-col items-center gap-3 px-6 py-14 text-center">
            <Brain className="h-10 w-10 text-primary/50" />
            <p className="text-sm text-muted-foreground">{t("mem.empty")}</p>
          </div>
        )}
      </div>

      {memories.length > 0 && (
        <button
          onClick={() => {
            if (window.confirm(t("mem.confirmClear"))) clearMutation.mutate();
            else toast.message(t("common.cancel"));
          }}
          className="mt-6 text-xs text-destructive/80 hover:text-destructive"
        >
          {t("mem.clearAll")}
        </button>
      )}
    </div>
  );
}
