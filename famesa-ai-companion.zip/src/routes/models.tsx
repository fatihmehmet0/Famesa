import { createFileRoute } from "@tanstack/react-router";
import { Check, Cpu } from "lucide-react";
import { toast } from "sonner";

import { AppShell, RequireAuth } from "@/components/app-shell";
import { useApp } from "@/lib/app-context";
import { AI_MODELS } from "@/lib/settings";

export const Route = createFileRoute("/models")({
  head: () => ({
    meta: [
      { title: "AI Modelleri — FAMESA AI" },
      { name: "description", content: "FAMESA AI model seçimi: OpenAI, Google ve Anthropic modelleri arasında geçiş yap." },
      { property: "og:title", content: "AI Modelleri — FAMESA AI" },
      { property: "og:description", content: "FAMESA AI model seçimi." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ModelsPage,
});

const PROVIDER_LABELS = { openai: "OpenAI", google: "Google", anthropic: "Anthropic" } as const;

function ModelsPage() {
  return (
    <RequireAuth>
      <AppShell>
        <Models />
      </AppShell>
    </RequireAuth>
  );
}

function Models() {
  const { t, settings, updateSettings } = useApp();

  return (
    <div className="mx-auto max-w-2xl px-4 py-8 sm:px-8">
      <div className="fade-up flex items-center gap-3">
        <Cpu className="h-6 w-6 text-primary" />
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">{t("models.title")}</h1>
          <p className="text-sm text-muted-foreground">{t("models.subtitle")}</p>
        </div>
      </div>

      <div className="mt-6 space-y-2">
        {AI_MODELS.map((model) => {
          const active = settings.default_model === model.id;
          return (
            <button
              key={model.id}
              onClick={async () => {
                await updateSettings({ default_model: model.id });
                toast.success(t("set.saved"));
              }}
              className={`glass-panel fade-up flex w-full items-center gap-4 px-4 py-4 text-left transition-all ${
                active ? "glow-edge" : "hover:scale-[1.01]"
              }`}
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-display text-sm font-semibold text-foreground">{model.label}</span>
                  <span className="rounded-full border border-border px-2 py-0.5 font-mono text-[9px] tracking-widest text-muted-foreground">
                    {PROVIDER_LABELS[model.provider]}
                  </span>
                  {active && (
                    <span className="rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-medium text-primary">
                      {t("models.active")}
                    </span>
                  )}
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{model.description}</p>
                <div className="mt-1.5 flex gap-1">
                  {model.capabilities.map((cap) => (
                    <span key={cap} className="rounded-md bg-accent/50 px-1.5 py-0.5 font-mono text-[9px] text-muted-foreground">
                      {cap}
                    </span>
                  ))}
                </div>
              </div>
              {active && <Check className="h-5 w-5 shrink-0 text-primary" />}
            </button>
          );
        })}
      </div>
    </div>
  );
}
