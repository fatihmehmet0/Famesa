import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Check } from "lucide-react";

import logoUrl from "@/assets/famesa-logo.png";
import { RequireAuth } from "@/components/app-shell";
import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-context";
import { LANGUAGES, type Language } from "@/lib/i18n";
import { AI_PERSONALITIES, THEMES, TTS_VOICES, type ThemeId } from "@/lib/settings";

export const Route = createFileRoute("/onboarding")({
  head: () => ({
    meta: [
      { title: "Kurulum — FAMESA AI" },
      { name: "description", content: "FAMESA AI ilk kurulum: isim, tema, dil ve AI kişiliği." },
      { property: "og:title", content: "Kurulum — FAMESA AI" },
      { property: "og:description", content: "FAMESA AI ilk kurulum." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: OnboardingPage,
});

const STEPS = ["name", "persona", "theme", "language", "voice"] as const;

function OnboardingPage() {
  return (
    <RequireAuth>
      <Onboarding />
    </RequireAuth>
  );
}

function Onboarding() {
  const { t, user, settings, updateSettings, refreshProfile } = useApp();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [persona, setPersona] = useState("samimi");
  const [saving, setSaving] = useState(false);

  const finish = async () => {
    setSaving(true);
    await updateSettings({ ai_personality: persona });
    if (user) {
      await supabase
        .from("profiles")
        .update({ display_name: name.trim() || null, onboarding_completed: true })
        .eq("id", user.id);
    }
    await refreshProfile();
    setSaving(false);
    void navigate({ to: "/" });
  };

  const next = () => (step === STEPS.length - 1 ? void finish() : setStep(step + 1));

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="ambient-field" />
      <div className="glass-panel-strong fade-up w-full max-w-md p-8">
        <div className="mb-6 flex items-center gap-3">
          <img src={logoUrl} alt="" className="h-10 w-10 drop-shadow-[0_0_14px_var(--color-glow)]" width={1024} height={1024} />
          <div className="font-mono text-[10px] tracking-[0.3em] text-muted-foreground">
            FAMESA SETUP · {step + 1}/{STEPS.length}
          </div>
        </div>

        {STEPS[step] === "name" && (
          <div className="fade-in">
            <h1 className="font-display text-2xl font-bold text-foreground">{t("onb.nameQ")}</h1>
            <p className="mt-1 text-sm text-muted-foreground">{t("onb.nameHint")}</p>
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="glass-panel mt-5 w-full px-4 py-3 text-foreground outline-none focus:ring-1 focus:ring-ring"
              placeholder="Fatih"
            />
          </div>
        )}

        {STEPS[step] === "persona" && (
          <div className="fade-in">
            <h1 className="font-display text-2xl font-bold text-foreground">{t("onb.personaQ")}</h1>
            <div className="mt-5 grid grid-cols-2 gap-2">
              {AI_PERSONALITIES.map((p) => (
                <button
                  key={p}
                  onClick={() => setPersona(p)}
                  className={`glass-panel px-4 py-3 text-sm capitalize transition-all ${
                    persona === p ? "glow-edge text-primary" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>
        )}

        {STEPS[step] === "theme" && (
          <div className="fade-in">
            <h1 className="font-display text-2xl font-bold text-foreground">{t("onb.themeQ")}</h1>
            <div className="mt-5 space-y-2">
              {THEMES.map((theme) => (
                <button
                  key={theme.id}
                  onClick={() => void updateSettings({ theme: theme.id as ThemeId })}
                  className={`glass-panel flex w-full items-center justify-between px-4 py-3.5 text-left transition-all ${
                    settings.theme === theme.id ? "glow-edge" : ""
                  }`}
                >
                  <div>
                    <div className="font-display text-sm font-semibold text-foreground">{t(theme.nameKey)}</div>
                    <div className="text-xs text-muted-foreground">{t(theme.descKey)}</div>
                  </div>
                  {settings.theme === theme.id && <Check className="h-4 w-4 text-primary" />}
                </button>
              ))}
            </div>
          </div>
        )}

        {STEPS[step] === "language" && (
          <div className="fade-in">
            <h1 className="font-display text-2xl font-bold text-foreground">{t("onb.langQ")}</h1>
            <div className="mt-5 grid grid-cols-2 gap-2">
              {LANGUAGES.map((lang) => (
                <button
                  key={lang.id}
                  onClick={() => void updateSettings({ language: lang.id as Language })}
                  className={`glass-panel px-4 py-3 text-sm transition-all ${
                    settings.language === lang.id ? "glow-edge text-primary" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {STEPS[step] === "voice" && (
          <div className="fade-in">
            <h1 className="font-display text-2xl font-bold text-foreground">{t("set.aiVoice")}</h1>
            <div className="mt-5 grid grid-cols-2 gap-2">
              {TTS_VOICES.map((voice) => (
                <button
                  key={voice}
                  onClick={() => void updateSettings({ tts_voice: voice })}
                  className={`glass-panel px-4 py-3 text-sm transition-all ${
                    settings.tts_voice === voice ? "glow-edge text-primary" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {voice}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="mt-8 flex items-center justify-between">
          <button onClick={() => void finish()} className="text-xs text-muted-foreground hover:text-foreground">
            {t("onb.skip")}
          </button>
          <button
            disabled={saving}
            onClick={next}
            className="rounded-xl bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground transition-transform hover:scale-105 active:scale-95 disabled:opacity-40"
          >
            {step === STEPS.length - 1 ? t("onb.start") : t("onb.next")}
          </button>
        </div>
      </div>
    </div>
  );
}
