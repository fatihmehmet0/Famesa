import { createServerFn } from "@tanstack/react-start";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// Security-gate verification. PIN and pattern are never stored or compared in
// plain text: only SHA-256 hashes salted with the owner's user id are kept,
// and all comparison happens here on the server with a constant-time check.

async function sha256Hex(text: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function timingSafeEqualHex(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function normalizePattern(input: unknown): string | null {
  if (!Array.isArray(input)) return null;
  if (input.length < 4 || input.length > 9) return null;
  if (!input.every((n) => Number.isInteger(n) && n >= 0 && n < 9)) return null;
  if (new Set(input).size !== input.length) return null;
  return input.join("-");
}

export const getSecurityStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase
      .from("user_settings")
      .select("pin_hash, pattern_hash")
      .eq("user_id", context.userId)
      .maybeSingle();
    return { pinSet: Boolean(data?.pin_hash), patternSet: Boolean(data?.pattern_hash) };
  });

export const verifyPin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { pin: string }) => data)
  .handler(async ({ context, data }) => {
    const { data: row } = await context.supabase
      .from("user_settings")
      .select("pin_hash")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (!row?.pin_hash || !/^\d{4}$/.test(data.pin)) return { ok: false as const };
    const hash = await sha256Hex(`${context.userId}:${data.pin}`);
    return { ok: timingSafeEqualHex(hash, row.pin_hash) };
  });

export const setupPattern = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { pattern: number[] }) => data)
  .handler(async ({ context, data }) => {
    const pattern = normalizePattern(data.pattern);
    if (!pattern) return { ok: false as const };
    const { data: row } = await context.supabase
      .from("user_settings")
      .select("pattern_hash")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (row?.pattern_hash) return { ok: false as const };
    const hash = await sha256Hex(`${context.userId}:${pattern}`);
    const { error } = await context.supabase
      .from("user_settings")
      .update({ pattern_hash: hash })
      .eq("user_id", context.userId);
    return { ok: !error };
  });

export const verifyPattern = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { pattern: number[] }) => data)
  .handler(async ({ context, data }) => {
    const pattern = normalizePattern(data.pattern);
    const { data: row } = await context.supabase
      .from("user_settings")
      .select("pattern_hash")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (!pattern || !row?.pattern_hash) return { ok: false as const };
    const hash = await sha256Hex(`${context.userId}:${pattern}`);
    return { ok: timingSafeEqualHex(hash, row.pattern_hash) };
  });
