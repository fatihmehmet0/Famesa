import type { Language } from "./i18n";

export type ThemeId = "ice" | "obsidian" | "glass";

export const THEMES: { id: ThemeId; nameKey: "theme.ice" | "theme.obsidian" | "theme.glass"; descKey: "theme.iceDesc" | "theme.obsidianDesc" | "theme.glassDesc" }[] = [
  { id: "ice", nameKey: "theme.ice", descKey: "theme.iceDesc" },
  { id: "obsidian", nameKey: "theme.obsidian", descKey: "theme.obsidianDesc" },
  { id: "glass", nameKey: "theme.glass", descKey: "theme.glassDesc" },
];

export interface UserSettings {
  theme: ThemeId;
  language: Language;
  font_size: "small" | "medium" | "large";
  animations_enabled: boolean;
  glass_intensity: "low" | "medium" | "high";
  ai_name: string;
  ai_personality: string;
  response_length: "short" | "balanced" | "detailed";
  default_model: string;
  tts_voice: string;
  voice_speed: number;
  auto_speak: boolean;
  notification_prefs: Record<string, boolean>;
}

export const DEFAULT_SETTINGS: UserSettings = {
  theme: "ice",
  language: "tr",
  font_size: "medium",
  animations_enabled: true,
  glass_intensity: "medium",
  ai_name: "FAMESA",
  ai_personality: "samimi",
  response_length: "balanced",
  default_model: "openai/gpt-6-astra",
  tts_voice: "Kore",
  voice_speed: 1,
  auto_speak: false,
  notification_prefs: { ai: true, social: true, system: true, sounds: false },
};

export const AI_PERSONALITIES = ["samimi", "profesyonel", "kısa", "detaylı", "teknik", "öğretici"] as const;

export const TTS_VOICES = ["Kore", "Puck", "Charon", "Fenrir", "Aoede", "Leda", "Orus", "Zephyr"] as const;

/** Provider-agnostic model registry. New providers/models are added here only. */
export interface ModelInfo {
  id: string;
  label: string;
  provider: "openai" | "google" | "anthropic";
  description: string;
  capabilities: ("text" | "vision" | "reasoning" | "fast")[];
}

export const AI_MODELS: ModelInfo[] = [
  { id: "openai/gpt-6-astra", label: "GPT-6 Astra", provider: "openai", description: "En güçlü akıl yürütme, kod ve analiz modeli.", capabilities: ["text", "vision", "reasoning"] },
  { id: "openai/gpt-6-sol", label: "GPT-6 Sol", provider: "openai", description: "Dengeli performans, günlük kullanım.", capabilities: ["text", "vision"] },
  { id: "openai/gpt-6-luna", label: "GPT-6 Luna", provider: "openai", description: "Hızlı ve ekonomik.", capabilities: ["text", "fast"] },
  { id: "google/gemini-4-argon", label: "Gemini 4 Argon", provider: "google", description: "Uzun bağlam ve kurumsal bilgi işi.", capabilities: ["text", "vision", "reasoning"] },
  { id: "google/gemini-3.8-flash", label: "Gemini 3.8 Flash", provider: "google", description: "Hızlı kodlama ve ajan iş akışları.", capabilities: ["text", "vision", "fast"] },
  { id: "anthropic/claude-opus-5-5", label: "Claude Opus 5.5", provider: "anthropic", description: "Uzun süreli ajan kodlama işleri.", capabilities: ["text", "vision", "reasoning"] },
  { id: "anthropic/claude-sonnet-5", label: "Claude Sonnet 5", provider: "anthropic", description: "Hız ve zeka dengesi.", capabilities: ["text", "vision"] },
];

export function applyAppearance(settings: UserSettings) {
  const root = document.documentElement;
  root.dataset["theme"] = settings.theme;
  root.lang = settings.language;
  root.dir = settings.language === "ar" ? "rtl" : "ltr";
  root.style.fontSize = settings.font_size === "small" ? "14px" : settings.font_size === "large" ? "17px" : "16px";
  const blur = settings.glass_intensity === "low" ? "8px" : settings.glass_intensity === "high" ? "26px" : undefined;
  if (blur) root.style.setProperty("--glass-blur", blur);
  else root.style.removeProperty("--glass-blur");
  root.classList.toggle("reduce-motion", !settings.animations_enabled);
}
