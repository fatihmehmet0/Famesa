import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";

import { supabase } from "@/integrations/supabase/client";
import { translate, type Language, type TranslationKey } from "./i18n";
import { applyAppearance, DEFAULT_SETTINGS, type UserSettings } from "./settings";

interface Profile {
  id: string;
  username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  onboarding_completed: boolean;
}

interface AppContextValue {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  settings: UserSettings;
  loading: boolean;
  t: (key: TranslationKey, vars?: Record<string, string>) => string;
  lang: Language;
  updateSettings: (patch: Partial<UserSettings>) => Promise<void>;
  refreshProfile: () => Promise<void>;
  signOut: () => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [settings, setSettings] = useState<UserSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);

  const loadProfile = useCallback(async (userId: string) => {
    const { data: profileRow } = await supabase.from("profiles").select("*").eq("id", userId).maybeSingle();
    setProfile(profileRow as Profile | null);
    const { data: settingsRow } = await supabase.from("user_settings").select("*").eq("user_id", userId).maybeSingle();
    if (settingsRow) {
      const merged = { ...DEFAULT_SETTINGS, ...(settingsRow as Partial<UserSettings>) } as UserSettings;
      setSettings(merged);
      applyAppearance(merged);
    } else {
      applyAppearance(DEFAULT_SETTINGS);
    }
  }, []);

  useEffect(() => {
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      if (nextSession?.user) {
        // defer to avoid Supabase re-entrancy issues
        setTimeout(() => void loadProfile(nextSession.user.id), 0);
      } else {
        setProfile(null);
        setSettings(DEFAULT_SETTINGS);
        applyAppearance(DEFAULT_SETTINGS);
      }
      setLoading(false);
    });
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session?.user) void loadProfile(data.session.user.id);
      else {
        applyAppearance(DEFAULT_SETTINGS);
        setLoading(false);
      }
    });
    return () => subscription.unsubscribe();
  }, [loadProfile]);

  const updateSettings = useCallback(
    async (patch: Partial<UserSettings>) => {
      const next = { ...settings, ...patch };
      setSettings(next);
      applyAppearance(next);
      if (session?.user) {
        await supabase.from("user_settings").update(patch).eq("user_id", session.user.id);
      }
    },
    [settings, session],
  );

  const refreshProfile = useCallback(async () => {
    if (session?.user) await loadProfile(session.user.id);
  }, [session, loadProfile]);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
  }, []);

  const value = useMemo<AppContextValue>(() => {
    const lang = settings.language;
    return {
      session,
      user: session?.user ?? null,
      profile,
      settings,
      loading,
      lang,
      t: (key, vars) => translate(lang, key, vars),
      updateSettings,
      refreshProfile,
      signOut,
    };
  }, [session, profile, settings, loading, updateSettings, refreshProfile, signOut]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}
