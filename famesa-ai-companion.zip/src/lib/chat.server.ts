import { convertToModelMessages, tool, type UIMessage } from "ai";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { z } from "zod";

import { createResponsesCall } from "./responses.ts";

const GATEWAY_URL = "https://ai.gateway.lovable.dev";

interface AuthedContext {
  supabase: SupabaseClient;
  userId: string;
  email: string | undefined;
}

async function getAuthContext(request: Request): Promise<AuthedContext | null> {
  const auth = request.headers.get("authorization");
  if (!auth?.startsWith("Bearer ")) return null;
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) return null;
  const supabase = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      headers: { Authorization: auth },
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();
  if (error || !user) return null;
  return { supabase, userId: user.id, email: user.email };
}

const PERSONALITY_HINTS: Record<string, string> = {
  samimi: "Samimi, sıcak ve doğal bir arkadaş gibi konuş.",
  profesyonel: "Profesyonel, net ve saygılı bir üslup kullan.",
  kısa: "Mümkün olduğunca kısa ve öz cevaplar ver.",
  "detaylı": "Detaylı, kapsamlı ve örneklerle destekli cevaplar ver.",
  teknik: "Teknik derinliği yüksek, uzman seviyesinde cevaplar ver.",
  "öğretici": "Bir öğretmen gibi adım adım, sabırla açıkla.",
};

const LENGTH_HINTS: Record<string, string> = {
  short: "Cevaplarını kısa tut; gereksiz detay verme.",
  balanced: "Cevapların dengeli uzunlukta olsun.",
  detailed: "Cevapların kapsamlı ve derinlemesine olsun.",
};

function buildInstructions(opts: {
  aiName: string;
  personality: string;
  responseLength: string;
  language: string;
  userName: string;
  memories: string[];
}): string {
  const langName =
    { tr: "Türkçe", en: "English", de: "Deutsch", es: "Español", fr: "Français", ar: "العربية" }[opts.language] ?? "Türkçe";
  const memoryBlock = opts.memories.length
    ? `\n\nKullanıcı hakkında hatırladığın bilgiler (yalnızca kullanıcının açıkça kaydetmek istedikleri):\n${opts.memories.map((m) => `- ${m}`).join("\n")}`
    : "";
  return `Sen ${opts.aiName} — kullanıcının kişisel, premium yapay zeka asistanısın. Kullanıcının adı: ${opts.userName}.

Kurallar:
- Her zaman ${langName} dilinde cevap ver (kullanıcı açıkça başka dil istemedikçe).
- ${PERSONALITY_HINTS[opts.personality] ?? PERSONALITY_HINTS["samimi"]}
- ${LENGTH_HINTS[opts.responseLength] ?? LENGTH_HINTS["balanced"]}
- Geniş bilgi alanlarında yardımcı ol: matematik, fizik, kimya, biyoloji, programlama, tarih, mühendislik, günlük yaşam ve daha fazlası.
- ASLA uydurma bilgi üretme. Emin olmadığın konularda bunu açıkça belirt ("Bu konuda tam emin değilim ama..." gibi). Sahte güven gösterme.
- Matematik ve hesaplama sorularında adım adım ilerle ve sonucu iki kez kontrol et.
- Kod sorularında çalışan, temiz kod ver; kod bloklarını dil etiketiyle yaz.
- Kullanıcının doğal konuşma dilini (argo dahil) anla ve bağlamına uygun, doğal yanıt ver.
- Kullanıcı senden açıkça bir bilgiyi hatırlamanı/ kaydetmeni isterse save_memory aracını kullan. Kullanıcı açıkça istemedikçe hiçbir kişisel bilgiyi kaydetme.
- Kullanıcı bir bilgiyi unutmanı isterse, bunu yapamayacağını nazikçe söyle ve Ayarlar > Hafıza bölümünden silebileceğini belirt.
- Görseller gönderildiğinde içeriğini dikkatle analiz et; görseldeki yazıları (Türkçe karakterler dahil) oku ve gerektiğinde çevir.${memoryBlock}`;
}

export async function handleChat(request: Request): Promise<Response> {
  try {
    const ctx = await getAuthContext(request);
    if (!ctx) return Response.json({ error: "unauthorized" }, { status: 401 });

    const body = (await request.json()) as {
      messages: UIMessage[];
      conversationId: string;
      model?: string;
    };
    const { messages, conversationId } = body;
    if (!Array.isArray(messages) || !conversationId) {
      return Response.json({ error: "invalid_request" }, { status: 400 });
    }

    // Authorize the conversation
    const { data: conversation } = await ctx.supabase
      .from("conversations")
      .select("id, user_id")
      .eq("id", conversationId)
      .eq("user_id", ctx.userId)
      .maybeSingle();
    if (!conversation) return Response.json({ error: "conversation_not_found" }, { status: 404 });

    // Load personalization
    const [{ data: settingsRow }, { data: memoriesRows }, { data: profileRow }] = await Promise.all([
      ctx.supabase.from("user_settings").select("*").eq("user_id", ctx.userId).maybeSingle(),
      ctx.supabase.from("memories").select("content").eq("user_id", ctx.userId).order("created_at", { ascending: true }).limit(100),
      ctx.supabase.from("profiles").select("display_name, username").eq("id", ctx.userId).maybeSingle(),
    ]);

    const instructions = buildInstructions({
      aiName: settingsRow?.ai_name ?? "FAMESA",
      personality: settingsRow?.ai_personality ?? "samimi",
      responseLength: settingsRow?.response_length ?? "balanced",
      language: settingsRow?.language ?? "tr",
      userName: profileRow?.display_name ?? profileRow?.username ?? "dostum",
      memories: (memoriesRows ?? []).map((m) => m.content as string),
    });

    // Persist the new user message (dedupe by SDK id)
    const lastMessage = messages[messages.length - 1];
    if (lastMessage?.role === "user") {
      const { error: insertError } = await ctx.supabase.from("messages").insert({
        conversation_id: conversationId,
        user_id: ctx.userId,
        sdk_id: lastMessage.id,
        role: "user",
        parts: lastMessage.parts,
      });
      if (insertError && insertError.code !== "23505") {
        console.error("user message insert failed", insertError);
      }
      await ctx.supabase.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", conversationId);
    }

    const model = body.model ?? settingsRow?.default_model ?? "openai/gpt-6-astra";
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) return Response.json({ error: "ai_not_configured" }, { status: 500 });

    const supabase = ctx.supabase;
    const userId = ctx.userId;
    const tools = {
      save_memory: tool({
        description:
          "Kullanıcının AÇIKÇA hatırlanmasını istediği kişisel bir bilgiyi kalıcı hafızaya kaydeder. Yalnızca kullanıcı açıkça istediğinde kullan.",
        inputSchema: z.object({
          content: z.string().min(1).max(500).describe("Hatırlanacak bilgi, kısa ve net"),
          category: z
            .enum(["kimlik", "tercih", "hedef", "proje", "genel"])
            .describe("Bilginin kategorisi"),
        }),
        execute: async ({ content, category }) => {
          const { error } = await supabase.from("memories").insert({ user_id: userId, content, category });
          if (error) return { saved: false };
          return { saved: true, content };
        },
      }),
    };

    const modelMessages = await convertToModelMessages(messages);
    const call = createResponsesCall(
      request,
      { baseURL: GATEWAY_URL, apiKey, model },
      modelMessages,
      instructions,
      {
        tools,
        originalMessages: messages,
        onFinish: async ({ responseMessage }: { responseMessage: UIMessage }) => {
          const { error } = await supabase.from("messages").insert({
            conversation_id: conversationId,
            user_id: userId,
            sdk_id: responseMessage.id,
            role: "assistant",
            parts: responseMessage.parts,
          });
          if (error) console.error("assistant message insert failed", error);
        },
      },
    );

    const response = await call.response();
    const headers = new Headers(response.headers);
    headers.set("Cache-Control", "no-store");
    return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
  } catch (error) {
    console.error("chat handler failed", error);
    return Response.json({ error: "chat_failed" }, { status: 500 });
  }
}
